/// <reference lib="deno.ns" />
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.93.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const REACT_CDN = "https://unpkg.com/react@18.3.1/umd/react.production.min.js";
const REACT_DOM_CDN = "https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js";
const TAILWIND_CDN = "https://cdn.tailwindcss.com";
const BABEL_CDN = "https://unpkg.com/@babel/standalone@7.26.10/babel.min.js";

function buildProductionHtml(files: Record<string, string>, appName: string): string {
  // Concatenate all files (non-App first, App last)
  const entries = Object.entries(files);
  const appEntry = entries.find(([n]) => n === "App.tsx");
  const others = entries.filter(([n]) => n !== "App.tsx").sort(([a], [b]) => a.localeCompare(b));
  const concatenatedCode = [...others.map(([, c]) => c), appEntry?.[1] ?? ""].join("\n\n");

  return `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="${appName} - Built with Blink AI" />
  <title>${appName}</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>⚡</text></svg>">
  <script src="${TAILWIND_CDN}"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            border: '#1a1a1a',
            background: '#050505',
            foreground: '#f5f5f5',
            primary: { DEFAULT: '#2563eb', foreground: '#ffffff' },
            muted: { DEFAULT: '#171717', foreground: '#a3a3a3' },
            card: { DEFAULT: '#111111', foreground: '#f5f5f5' },
            accent: { DEFAULT: '#1d4ed8', foreground: '#ffffff' },
          }
        }
      }
    };
  </script>
  <script src="${REACT_CDN}"></script>
  <script src="${REACT_DOM_CDN}"></script>
  <script src="${BABEL_CDN}"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      background: #050505; 
      color: #f5f5f5; 
      font-family: 'Inter', system-ui, -apple-system, sans-serif; 
      min-height: 100vh; 
    }
    #root { min-height: 100vh; }
    .error-container { 
      padding: 2rem; 
      color: #ef4444; 
      font-family: monospace; 
      font-size: 13px; 
      white-space: pre-wrap; 
      background: #1a0000; 
      min-height: 100vh; 
    }
  </style>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel" data-type="module">
${concatenatedCode}
  </script>
  <script>
    window.addEventListener('error', function(e) {
      var root = document.getElementById('root');
      if (root) {
        root.innerHTML = '<div class="error-container"><strong>Runtime Error:</strong>\\n\\n' + 
          (e.message || 'Unknown error') + '</div>';
      }
    });
  </script>
</body>
</html>`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !SUPABASE_SERVICE_ROLE_KEY) {
      return new Response(JSON.stringify({ error: "Backend not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = authHeader.slice("Bearer ".length);
    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: claimsData, error: claimsErr } = await userClient.auth.getClaims(token);
    if (claimsErr || !claimsData?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = claimsData.claims.sub as string;

    // Use service role for storage operations
    const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const body = await req.json();
    const { projectId, files, appName } = body as {
      projectId: string;
      files: Record<string, string>;
      appName?: string;
    };

    if (!projectId || !files || typeof files !== "object") {
      return new Response(JSON.stringify({ error: "projectId and files are required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify project ownership
    const { data: project, error: projErr } = await userClient
      .from("projects")
      .select("id, name, user_id")
      .eq("id", projectId)
      .eq("user_id", userId)
      .single();

    if (projErr || !project) {
      return new Response(JSON.stringify({ error: "Project not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const finalAppName = appName || (project as any).name || "Blink App";

    // Build HTML
    const html = buildProductionHtml(files, finalAppName);

    // Generate unique deployment slug
    const slug = `${finalAppName.toLowerCase().replace(/[^a-z0-9]/g, "-").slice(0, 30)}-${Date.now().toString(36)}`;
    const storagePath = `${userId}/${slug}/index.html`;

    // Upload to storage
    const { error: uploadErr } = await adminClient.storage
      .from("deployments")
      .upload(storagePath, html, {
        contentType: "text/html",
        upsert: true,
      });

    if (uploadErr) {
      console.error("Upload error:", uploadErr);
      return new Response(JSON.stringify({ error: "Failed to upload deployment" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get public URL
    const { data: urlData } = adminClient.storage.from("deployments").getPublicUrl(storagePath);
    const publicUrl = urlData?.publicUrl;

    // Create deployment record
    const { data: deployment, error: depErr } = await userClient
      .from("deployments")
      .insert({
        user_id: userId,
        project_id: projectId,
        slug,
        schema_snapshot: { __code: true, files, app_name: finalAppName },
        is_public: true,
      })
      .select("id, created_at")
      .single();

    if (depErr) {
      console.error("Deployment record error:", depErr);
      return new Response(JSON.stringify({ error: "Failed to create deployment record" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        deploymentId: (deployment as any).id,
        slug,
        url: publicUrl,
        createdAt: (deployment as any).created_at,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("build-deploy error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
