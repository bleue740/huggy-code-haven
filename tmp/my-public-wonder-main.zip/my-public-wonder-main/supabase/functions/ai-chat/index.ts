/// <reference lib="deno.ns" />
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.93.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

type ReqBody = {
  projectId?: string;
  files?: Record<string, string>;
  code?: string;
  messages: { role: "user" | "assistant"; content: string }[];
};

type ToolCall = {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
};

function sse(data: unknown) {
  return `data: ${JSON.stringify(data)}\n\n`;
}

function safeJsonParse(text: string) {
  try {
    return { ok: true as const, value: JSON.parse(text) };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : "Invalid JSON" };
  }
}

function slugify(input: string) {
  return (input || "app")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 64);
}

function serializeFiles(files: Record<string, string>): string {
  if (Object.keys(files).length === 1 && files["App.tsx"]) return files["App.tsx"];
  return JSON.stringify({ __multifile: true, files });
}

function deserializeFiles(raw: string | null | undefined): Record<string, string> {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    if (parsed?.__multifile && typeof parsed.files === "object") return parsed.files;
    return { "App.tsx": raw };
  } catch {
    return { "App.tsx": raw };
  }
}

// ============= SCHEMA VALIDATION =============

interface ValidationError {
  path: string;
  message: string;
}

interface ValidationResult {
  ok: boolean;
  errors: ValidationError[];
  summary: string;
}

function validateFiles(files: Record<string, string>): ValidationResult {
  const errors: ValidationError[] = [];

  // Check App.tsx exists
  if (!files["App.tsx"]) {
    errors.push({ path: "files", message: "App.tsx is required as the main entry point" });
  }

  // Check App.tsx has ReactDOM.createRoot
  if (files["App.tsx"] && !files["App.tsx"].includes("createRoot") && !files["App.tsx"].includes("render")) {
    errors.push({ path: "App.tsx", message: "Must contain ReactDOM.createRoot(...).render(...)" });
  }

  // Check total size
  const totalSize = Object.values(files).reduce((sum, code) => sum + (code?.length ?? 0), 0);
  if (totalSize > 500_000) {
    errors.push({ path: "files", message: `Total code too large: ${(totalSize / 1000).toFixed(0)}KB (max 500KB)` });
  }

  // Check each file
  for (const [name, code] of Object.entries(files)) {
    if (!name.endsWith(".tsx") && !name.endsWith(".ts")) {
      errors.push({ path: name, message: "File must have .tsx or .ts extension" });
    }
    if (!code || code.trim().length === 0) {
      errors.push({ path: name, message: "File is empty" });
    }
    if (code && code.length > 100_000) {
      errors.push({ path: name, message: `File too large: ${(code.length / 1000).toFixed(0)}KB (max 100KB)` });
    }
    // Check for import/export statements (not allowed in this environment)
    if (code && (code.includes("import ") || code.includes("export "))) {
      errors.push({ path: name, message: "import/export statements are not supported. Components are global." });
    }
  }

  return {
    ok: errors.length === 0,
    errors,
    summary: errors.length === 0
      ? "Validation passed"
      : `${errors.length} error(s): ${errors.map(e => e.message).join("; ")}`,
  };
}

// ============= MULTI-AGENT SYSTEM =============

const ARCHITECT_PROMPT = `Tu es l'ARCHITECTE. Ton rôle est d'analyser la demande utilisateur et de produire un PLAN de modification.

RÈGLES:
1. Analyse la demande et les fichiers existants
2. Produis un plan CONCIS (max 5 lignes) décrivant:
   - Les composants React à créer/modifier
   - Les fichiers concernés
   - L'approche technique
3. NE génère PAS de code, seulement le plan textuel
4. Réponds UNIQUEMENT avec le plan, sans préambule

EXEMPLE DE SORTIE:
"Plan: Créer Header.tsx avec navigation responsive. Modifier App.tsx pour intégrer Header. Ajouter state pour menu mobile. Utiliser Tailwind pour le style."`;

const CODER_PROMPT = `Tu es Blink AI, un agent expert en React qui génère du VRAI code React/TSX multi-fichiers.

STRUCTURE MULTI-FICHIERS:
- App.tsx: Composant principal (OBLIGATOIRE). Se termine par ReactDOM.createRoot.
- [Nom].tsx: Composants réutilisables (Header.tsx, Sidebar.tsx, Dashboard.tsx, etc.)
- Tous les fichiers sont exécutés dans le même scope global du navigateur.
- PAS d'import/export. Les composants des autres fichiers sont disponibles globalement.
- Les fichiers non-App contiennent UNIQUEMENT des définitions de composants/fonctions.

RÈGLES CRITIQUES:
1. Tu génères TOUJOURS du code React complet et fonctionnel.
2. Globals disponibles: React, ReactDOM. Hooks via destructuration: const { useState, useEffect } = React;
3. Tu utilises Tailwind CSS pour tout le style.
4. App.tsx DOIT se terminer par:
   const root = ReactDOM.createRoot(document.getElementById('root'));
   root.render(React.createElement(App));
5. PAS d'import/export, PAS de require, PAS de modules ES.
6. Pour les icônes, utilise des SVG inline ou des emojis.
7. Génère des applications riches et interactives avec du state, des animations.
8. Si l'utilisateur parle français, réponds en français. Sinon en anglais.
9. Quand tu dois modifier l'app, appelle update_project_files avec TOUS les fichiers.
10. Ne génère JAMAIS de code partiel. Toujours les fichiers complets.
11. Organise le code: composants réutilisables dans des fichiers séparés.
12. Pour les apps complexes, sépare en 3-6 fichiers pour une bonne organisation.

EXEMPLE MULTI-FICHIERS:
Fichier Header.tsx:
\`\`\`
function Header({ title, onMenuClick }) {
  return (
    <header className="bg-[#111] border-b border-white/5 px-6 py-4 flex items-center justify-between">
      <h1 className="text-xl font-bold text-white">{title}</h1>
      <button onClick={onMenuClick} className="text-neutral-400 hover:text-white">☰</button>
    </header>
  );
}
\`\`\`

Fichier App.tsx:
\`\`\`
const { useState } = React;

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div className="min-h-screen bg-[#050505] text-white">
      <Header title="My App" onMenuClick={() => setMenuOpen(!menuOpen)} />
      <main className="p-6">
        <p>Content here</p>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App));
\`\`\``;

const REVIEWER_PROMPT = `Tu es le REVIEWER. Ton rôle est de valider le code généré et identifier les erreurs.

RÈGLES:
1. Vérifie que App.tsx existe et contient ReactDOM.createRoot
2. Vérifie qu'il n'y a pas d'import/export
3. Vérifie la cohérence des composants utilisés
4. Vérifie que le code est complet (pas de "..." ou TODO)
5. Si OK: réponds "VALIDATION: OK"
6. Si erreurs: réponds "VALIDATION: ERREURS" suivi de la liste des problèmes

EXEMPLE SORTIE OK:
"VALIDATION: OK - Le code est complet et fonctionnel."

EXEMPLE SORTIE ERREURS:
"VALIDATION: ERREURS
1. Header.tsx utilise 'import' qui n'est pas supporté
2. App.tsx ne contient pas ReactDOM.createRoot
3. Le composant Sidebar est utilisé mais pas défini"`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY)
      return new Response(JSON.stringify({ error: "Backend not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    if (!LOVABLE_API_KEY)
      return new Response(JSON.stringify({ error: "AI is not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader.startsWith("Bearer "))
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    const token = authHeader.slice("Bearer ".length);
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: claimsData, error: claimsErr } = await supabase.auth.getClaims(token);
    if (claimsErr || !claimsData?.claims?.sub)
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    const userId = claimsData.claims.sub as string;

    const body = (await req.json()) as ReqBody;
    const projectId = body?.projectId;
    const messagesIn = Array.isArray(body?.messages) ? body.messages : [];

    let currentFiles: Record<string, string> = body?.files
      ? body.files
      : body?.code
        ? { "App.tsx": body.code }
        : {};

    if (!projectId)
      return new Response(JSON.stringify({ error: "projectId is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    const { data: projectRow, error: projErr } = await supabase
      .from("projects")
      .select("id, name, schema, code, user_id")
      .eq("id", projectId)
      .single();

    if (projErr || !projectRow)
      return new Response(JSON.stringify({ error: "Project not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    if (Object.keys(currentFiles).length === 0) {
      currentFiles = deserializeFiles((projectRow as any).code);
    }

    // --- Tools ---
    const tools = [
      {
        type: "function",
        function: {
          name: "update_project_files",
          description:
            "Create or update files in the project. Pass a map of filename to complete code content. " +
            "Always include App.tsx as the main entry point. All files are executed in a single browser scope (no imports/exports). " +
            "Components defined in other files are available globally. " +
            "App.tsx MUST end with: const root = ReactDOM.createRoot(document.getElementById('root')); root.render(React.createElement(App)); " +
            "Other files should ONLY contain component/function definitions, NOT ReactDOM.createRoot.",
          parameters: {
            type: "object",
            properties: {
              files: {
                type: "object",
                description: "Map of filename to code content. Keys are filenames like 'App.tsx', 'Header.tsx', etc.",
                additionalProperties: { type: "string" },
              },
              appName: { type: "string", description: "Short name for the app (optional)" },
            },
            required: ["files"],
            additionalProperties: false,
          },
        },
      },
      {
        type: "function",
        function: {
          name: "publish_project",
          description: "Create a new deployment from the current project and return the deployment id/url.",
          parameters: { type: "object", properties: {}, additionalProperties: false },
        },
      },
      {
        type: "function",
        function: {
          name: "search_web",
          description: "Search the web for up-to-date information.",
          parameters: {
            type: "object",
            properties: {
              query: { type: "string", description: "Search query" },
              limit: { type: "number", description: "Max results (default 5)" },
            },
            required: ["query"],
            additionalProperties: false,
          },
        },
      },
    ];

    // --- Streaming response ---
    const stream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        const send = (obj: unknown) => controller.enqueue(encoder.encode(sse(obj)));
        const sendStatus = (text: string) => send({ type: "status", text });
        const sendTool = (text: string) => send({ type: "tool", text });
        const sendError = (text: string) => send({ type: "error", text });
        const sendDelta = (text: string) => send({ type: "delta", text });

        let webSearchCount = 0;
        const WEB_SEARCH_BUDGET = 2;
        const webCache = new Map<string, any>();

        const callAI = async (messages: any[], useTools: boolean = true, stream: boolean = true) => {
          const payload: any = {
            model: "google/gemini-3-flash-preview",
            stream,
            messages,
          };
          if (useTools) {
            payload.tools = tools;
            payload.tool_choice = "auto";
          }

          return fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
        };

        const execTool = async (toolCall: ToolCall) => {
          const name = toolCall.function.name;
          const argsText = toolCall.function.arguments || "{}";
          const parsedArgs = safeJsonParse(argsText);
          if (!parsedArgs.ok)
            return { ok: false, result: { error: `Invalid arguments: ${parsedArgs.error}` } };

          if (name === "update_project_files") {
            const files = (parsedArgs.value as any)?.files as Record<string, string>;
            const appName = (parsedArgs.value as any)?.appName as string | undefined;

            if (!files || typeof files !== "object")
              return { ok: false, result: { error: "files map is required" } };

            // Validate files
            const validation = validateFiles(files);
            if (!validation.ok) {
              return { ok: false, result: { error: validation.summary, errors: validation.errors } };
            }

            const serialized = serializeFiles(files);
            const updateData: Record<string, any> = { code: serialized };
            if (typeof appName === "string" && appName.trim()) updateData.name = appName.trim();

            const { error } = await supabase.from("projects").update(updateData).eq("id", projectId);
            if (error) return { ok: false, result: { error: error.message } };

            currentFiles = files;
            return { ok: true, result: { success: true, fileCount: Object.keys(files).length } };
          }

          if (name === "publish_project") {
            const appName = (projectRow as any).name || "app";
            const slug = slugify(String(appName));

            const { data: dep, error } = await supabase
              .from("deployments")
              .insert({
                user_id: userId,
                project_id: projectId,
                slug,
                schema_snapshot: { __code: true, files: currentFiles, app_name: appName },
                is_public: true,
              })
              .select("id")
              .single();

            if (error || !dep) return { ok: false, result: { error: error?.message ?? "Publish failed" } };
            return { ok: true, result: { deploymentId: (dep as any).id } };
          }

          if (name === "search_web") {
            const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY");
            if (!FIRECRAWL_API_KEY)
              return { ok: false, result: { error: "Web search is not configured" } };

            const query = String((parsedArgs.value as any)?.query ?? "").trim();
            const limit = Math.max(1, Math.min(10, Number((parsedArgs.value as any)?.limit) || 5));

            if (!query) return { ok: false, result: { error: "query is required" } };

            const cacheKey = JSON.stringify({ query, limit });
            const cached = webCache.get(cacheKey);
            if (cached) return { ok: true, result: { query, results: cached, cached: true } };

            if (webSearchCount >= WEB_SEARCH_BUDGET)
              return { ok: false, result: { error: `Web search budget exceeded (max ${WEB_SEARCH_BUDGET})` } };
            webSearchCount++;

            const resp = await fetch("https://api.firecrawl.dev/v1/search", {
              method: "POST",
              headers: { Authorization: `Bearer ${FIRECRAWL_API_KEY}`, "Content-Type": "application/json" },
              body: JSON.stringify({ query, limit }),
            });

            const data = await resp.json().catch(() => null);
            if (!resp.ok) return { ok: false, result: { error: `Search error [${resp.status}]` } };

            const rows = Array.isArray((data as any)?.data) ? (data as any).data : [];
            const results = rows.slice(0, limit).map((r: any) => ({ url: r?.url, title: r?.title, description: r?.description }));
            webCache.set(cacheKey, results);
            return { ok: true, result: { query, results, cached: false } };
          }

          return { ok: false, result: { error: `Unknown tool: ${name}` } };
        };

        try {
          // ============= PHASE 1: ARCHITECT =============
          sendStatus("🏗️ Architecte — analyse de la demande…");

          const latestUser = [...messagesIn].reverse().find((m) => m.role === "user")?.content ?? "";
          const fileContext = Object.keys(currentFiles).length > 0
            ? `\n\nFichiers actuels: ${Object.keys(currentFiles).join(", ")}`
            : "\n\nAucun fichier existant.";

          let planText = "";
          try {
            const archResp = await callAI([
              { role: "system", content: ARCHITECT_PROMPT },
              { role: "user", content: `Demande: ${latestUser}${fileContext}` },
            ], false, false);

            if (archResp.ok) {
              const archJson = await archResp.json().catch(() => null);
              planText = archJson?.choices?.[0]?.message?.content ?? "";
            }
          } catch (e) {
            console.error("Architect error:", e);
          }

          if (planText) {
            sendTool("🏗️ Architecte: plan prêt");
            send({ type: "architect_plan", plan: planText });
          }

          // ============= PHASE 2: CODER =============
          sendStatus("💻 Codeur — génération du code React…");

          const chatMessages: any[] = [{ role: "system", content: CODER_PROMPT }];

          if (Object.keys(currentFiles).length > 0) {
            const fileList = Object.entries(currentFiles)
              .map(([name, code]) => `=== ${name} ===\n${code}`)
              .join("\n\n");
            chatMessages.push({
              role: "system",
              content: "Fichiers actuels du projet. Si tu les modifies, appelle update_project_files avec TOUS les fichiers:\n\n" + fileList,
            });
          }

          if (planText) {
            chatMessages.push({
              role: "system",
              content: "PLAN DE L'ARCHITECTE (suis ce plan):\n" + planText,
            });
          }

          chatMessages.push(...messagesIn);

          let iterations = 0;
          const MAX_ITERATIONS = 6;
          let lastToolError: string | null = null;

          while (iterations < MAX_ITERATIONS) {
            iterations++;

            // Add error context for auto-fix
            if (lastToolError) {
              chatMessages.push({
                role: "system",
                content: `ERREUR PRÉCÉDENTE (corrige-la): ${lastToolError}`,
              });
              lastToolError = null;
            }

            const gatewayResp = await callAI(chatMessages, true, true);

            if (!gatewayResp.ok || !gatewayResp.body) {
              if (gatewayResp.status === 429) { sendError("Rate limit dépassé."); break; }
              if (gatewayResp.status === 402) { sendError("Crédits IA épuisés."); break; }
              sendError("Erreur IA.");
              break;
            }

            const reader = gatewayResp.body.getReader();
            const decoder = new TextDecoder();
            let buf = "";
            let toolCalls: ToolCall[] = [];
            let sawToolFinish = false;

            const mergeToolDelta = (deltaCalls: any[]) => {
              for (const dc of deltaCalls) {
                const idx = typeof dc.index === "number" ? dc.index : 0;
                const existing = toolCalls[idx] ?? {
                  id: dc.id ?? crypto.randomUUID(),
                  type: "function",
                  function: { name: "", arguments: "" },
                };
                if (dc.id) existing.id = dc.id;
                if (dc.type) existing.type = dc.type;
                if (dc.function?.name) existing.function.name += dc.function.name;
                if (dc.function?.arguments) existing.function.arguments += dc.function.arguments;
                toolCalls[idx] = existing;
              }
            };

            let done = false;
            while (!done) {
              const { value, done: d } = await reader.read();
              if (d) break;
              buf += decoder.decode(value, { stream: true });

              let nl: number;
              while ((nl = buf.indexOf("\n")) !== -1) {
                let line = buf.slice(0, nl);
                buf = buf.slice(nl + 1);
                if (line.endsWith("\r")) line = line.slice(0, -1);
                if (line.startsWith(":") || line.trim() === "") continue;
                if (!line.startsWith("data: ")) continue;

                const jsonStr = line.slice(6).trim();
                if (jsonStr === "[DONE]") { done = true; break; }

                let parsed: any;
                try { parsed = JSON.parse(jsonStr); } catch { buf = line + "\n" + buf; break; }

                const choice = parsed?.choices?.[0];
                const delta = choice?.delta;
                const finish = choice?.finish_reason;

                const content = delta?.content as string | undefined;
                if (content) sendDelta(content);

                const deltaToolCalls = delta?.tool_calls as any[] | undefined;
                if (Array.isArray(deltaToolCalls) && deltaToolCalls.length) mergeToolDelta(deltaToolCalls);

                if (finish === "tool_calls") sawToolFinish = true;
              }
            }

            // Flush leftovers
            if (buf.trim()) {
              for (let raw of buf.split("\n")) {
                if (!raw) continue;
                if (raw.endsWith("\r")) raw = raw.slice(0, -1);
                if (raw.startsWith(":") || raw.trim() === "") continue;
                if (!raw.startsWith("data: ")) continue;
                const jsonStr = raw.slice(6).trim();
                if (jsonStr === "[DONE]") continue;
                try {
                  const parsed = JSON.parse(jsonStr);
                  const choice = parsed?.choices?.[0];
                  const delta = choice?.delta;
                  if (delta?.content) sendDelta(delta.content);
                  if (Array.isArray(delta?.tool_calls)) mergeToolDelta(delta.tool_calls);
                  if (choice?.finish_reason === "tool_calls") sawToolFinish = true;
                } catch { /* ignore */ }
              }
            }

            if (!sawToolFinish || toolCalls.length === 0) {
              break;
            }

            sendStatus("🔧 Application des modifications…");

            const assistantToolMsg = {
              role: "assistant",
              tool_calls: toolCalls.map((tc) => ({
                id: tc.id,
                type: "function",
                function: { name: tc.function.name, arguments: tc.function.arguments },
              })),
            };
            chatMessages.push(assistantToolMsg);

            let hasError = false;
            for (const tc of toolCalls) {
              sendTool(`🔧 Tool: ${tc.function.name}`);
              const res = await execTool(tc);
              
              if (!res.ok) {
                hasError = true;
                lastToolError = (res.result as any)?.error ?? "unknown error";
                sendError(`❌ ${tc.function.name}: ${lastToolError}`);
              } else if (tc.function.name === "update_project_files") {
                sendTool(`✅ ${Object.keys(currentFiles).length} fichier(s) mis à jour`);
                send({ type: "files_update", files: currentFiles });
              }

              chatMessages.push({
                role: "tool",
                tool_call_id: tc.id,
                content: JSON.stringify(res.result),
              });
            }

            // If there was an error, continue loop for auto-fix
            if (hasError) {
              sendStatus("🔄 Auto-correction en cours…");
              continue;
            }
          }

          // ============= PHASE 3: REVIEWER =============
          if (Object.keys(currentFiles).length > 0) {
            sendStatus("🔍 Reviewer — validation du code…");

            try {
              const fileList = Object.entries(currentFiles)
                .map(([name, code]) => `=== ${name} ===\n${code.slice(0, 2000)}${code.length > 2000 ? "\n[...tronqué]" : ""}`)
                .join("\n\n");

              const reviewResp = await callAI([
                { role: "system", content: REVIEWER_PROMPT },
                { role: "user", content: `Valide ce code:\n\n${fileList}` },
              ], false, false);

              if (reviewResp.ok) {
                const reviewJson = await reviewResp.json().catch(() => null);
                const reviewText = reviewJson?.choices?.[0]?.message?.content ?? "";

                if (reviewText.includes("VALIDATION: OK")) {
                  sendTool("✅ Reviewer: code validé");
                } else if (reviewText.includes("VALIDATION: ERREURS")) {
                  sendError("⚠️ Reviewer: problèmes détectés");
                  send({ type: "review", text: reviewText });
                }
              }
            } catch (e) {
              console.error("Reviewer error:", e);
            }
          }

          sendStatus("✨ Génération terminée");
        } catch (err) {
          console.error("ai-chat stream error:", err);
          sendError("Erreur serveur pendant la génération.");
        } finally {
          controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("ai-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
