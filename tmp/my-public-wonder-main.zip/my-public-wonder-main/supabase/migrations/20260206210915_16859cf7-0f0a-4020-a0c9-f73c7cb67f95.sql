
-- Add code column to projects for storing generated React/TSX code
ALTER TABLE public.projects ADD COLUMN code text;

-- Add a comment for documentation
COMMENT ON COLUMN public.projects.code IS 'Generated React/TSX source code for the project (Phase 1: single component)';
