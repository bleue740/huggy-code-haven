-- Create users_credits table for credit system
CREATE TABLE public.users_credits (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  credits INTEGER NOT NULL DEFAULT 100,
  lifetime_used INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.users_credits ENABLE ROW LEVEL SECURITY;

-- Users can view their own credits
CREATE POLICY "Users can view their own credits"
  ON public.users_credits FOR SELECT
  USING (auth.uid() = user_id);

-- Users can update their own credits (for decrement)
CREATE POLICY "Users can update their own credits"
  ON public.users_credits FOR UPDATE
  USING (auth.uid() = user_id);

-- Users can insert their own credits row
CREATE POLICY "Users can insert their own credits"
  ON public.users_credits FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Create trigger for updated_at
CREATE TRIGGER update_users_credits_updated_at
  BEFORE UPDATE ON public.users_credits
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for built deployments
INSERT INTO storage.buckets (id, name, public) VALUES ('deployments', 'deployments', true);

-- Storage policies for deployments bucket
CREATE POLICY "Public deployments are viewable"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'deployments');

CREATE POLICY "Users can upload their deployments"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'deployments' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their deployments"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'deployments' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their deployments"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'deployments' AND auth.uid()::text = (storage.foldername(name))[1]);