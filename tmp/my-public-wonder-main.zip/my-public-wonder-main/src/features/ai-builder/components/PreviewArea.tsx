import React, { useMemo, useCallback, useState } from "react";
import {
  Loader2,
  Edit3,
  BarChart,
  Layout as LayoutIcon,
  ExternalLink,
  X,
  Globe,
  CheckCircle2,
  Monitor,
  Tablet,
  Smartphone,
  Maximize2,
  Minimize2,
  Settings,
  ChevronRight,
  Type as TypeIcon,
  Link2,
  Rocket,
} from "lucide-react";

interface PreviewAreaProps {
  isGenerating: boolean;
  isDeploying?: boolean;
  deploymentProgress?: number;
  deployedUrl?: string | null;
  customDomain?: string | null;
  codeContent: string;
  selectedWidgetId?: string;
  onSelectWidget: (id: string) => void;
  onCloseDeployModal?: () => void;
  onUpdateWidget?: (id: string, props: Record<string, unknown>) => void;
  onSetCustomDomain?: (domain: string) => void;
}

type DeviceMode = "desktop" | "tablet" | "mobile" | "iphone" | "ipad" | "macbook";

export const PreviewArea: React.FC<PreviewAreaProps> = ({
  isGenerating,
  isDeploying,
  deploymentProgress = 0,
  deployedUrl,
  customDomain,
  codeContent,
  selectedWidgetId,
  onSelectWidget,
  onCloseDeployModal,
  onUpdateWidget,
  onSetCustomDomain,
}) => {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>("desktop");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [domainInput, setDomainInput] = useState("");

  const result = useMemo(() => {
    try {
      const parsed = JSON.parse(codeContent) as any;
      return {
        valid: true,
        components: (parsed.components ?? []) as any[],
        appName: (parsed.app_name ?? "My App") as string,
      };
    } catch {
      return { valid: false, components: [] as any[], appName: "Invalid JSON" };
    }
  }, [codeContent]);

  const selectedComponent = useMemo(() => {
    if (!selectedWidgetId) return null;
    const findRecursive = (components: any[]): any => {
      for (const comp of components) {
        if (comp.id === selectedWidgetId) return comp;
        if (comp.children) {
          const found = findRecursive(comp.children);
          if (found) return found;
        }
      }
      return null;
    };
    return findRecursive(result.components);
  }, [selectedWidgetId, result.components]);

  const renderComponent = useCallback(
    (comp: any) => {
      if (!comp) return null;
      const isSelected = selectedWidgetId === comp.id;
      const baseClasses = `relative transition-all duration-200 cursor-pointer rounded-lg border-2 ${
        isSelected ? "border-primary ring-4 ring-primary/10" : "border-transparent hover:border-primary/30"
      }`;

      const handleComponentClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onSelectWidget(comp.id);
      };

      const children = comp.children?.map((child: any) => renderComponent(child));

      switch (comp.type) {
        case "NAVBAR":
          return (
            <nav
              key={comp.id}
              onClick={handleComponentClick}
              className={`${baseClasses} bg-card border-b border-border px-6 py-4 flex items-center justify-between mb-6 sticky top-0 z-10 shadow-sm`}
            >
              <div className="flex items-center gap-2 font-bold text-foreground">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-black">
                  B
                </div>
                {comp.title || "Blink App"}
              </div>
              <div className="flex gap-4 text-sm font-medium text-muted-foreground">
                <span className="hover:text-foreground">Dashboard</span>
                <span className="hover:text-foreground">Settings</span>
              </div>
            </nav>
          );

        case "CONTAINER": {
          const cols = (comp.columns as number) || 1;
          const isSmall = deviceMode === "mobile" || deviceMode === "iphone";
          const isMed = deviceMode === "tablet" || deviceMode === "ipad";
          const responsiveCols = isSmall ? 1 : isMed ? Math.min(cols, 2) : cols;
          return (
            <div
              key={comp.id}
              onClick={handleComponentClick}
              className={`${baseClasses} grid gap-6 mb-6 w-full px-6`}
              style={{ gridTemplateColumns: `repeat(${responsiveCols}, minmax(0, 1fr))` }}
            >
              {children}
              {isSelected && <SelectionBadge />}
            </div>
          );
        }

        case "HEADER":
          return (
            <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} mb-8 px-6 text-center md:text-left`}>
              <h1 className="text-3xl md:text-4xl font-black text-foreground tracking-tight leading-tight">
                {comp.title || "Header"}
              </h1>
              {comp.subtitle && <p className="text-muted-foreground text-base md:text-lg mt-2 font-medium">{comp.subtitle}</p>}
              {isSelected && <SelectionBadge />}
            </div>
          );

        case "CARD":
          return (
            <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} bg-card p-6 rounded-2xl border border-border shadow-sm`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-foreground text-lg">{comp.title || "Card"}</h3>
                <LayoutIcon size={16} className="text-primary" />
              </div>
              <div className="text-muted-foreground text-sm leading-relaxed mb-4">{comp.content}</div>
              {children}
              {isSelected && <SelectionBadge />}
            </div>
          );

        case "TABLE": {
          const data = (comp.data as any[][]) || [["Nom", "Status"]];
          return (
            <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} bg-card rounded-2xl border border-border shadow-sm overflow-hidden mb-8`}>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-muted border-b border-border">
                    <tr>
                      {data[0]?.map((cell: any, i: number) => (
                        <th key={i} className="px-6 py-3 font-bold text-muted-foreground uppercase text-[10px] tracking-widest">
                          {cell}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {data.slice(1).map((row: any, i: number) => (
                      <tr key={i} className="border-b border-border hover:bg-accent">
                        {row.map((cell: any, j: number) => (
                          <td key={j} className="px-6 py-4 text-foreground">
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {isSelected && <SelectionBadge />}
            </div>
          );
        }

        case "CHART":
          return (
            <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} bg-card p-6 rounded-2xl border border-border shadow-sm mb-6`}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-foreground">{comp.title || "Graph"}</h3>
                <BarChart size={18} className="text-primary" />
              </div>
              <div className="h-32 flex items-end gap-2">
                {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
                  <div key={i} className="flex-1 bg-primary rounded-t-md opacity-20" style={{ height: `${h}%` }} />
                ))}
              </div>
              {isSelected && <SelectionBadge />}
            </div>
          );

        case "BUTTON":
          return (
            <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} inline-block mb-4`}>
              <button className="px-6 py-3 rounded-xl font-bold text-sm bg-primary text-primary-foreground">
                {comp.label || "Action"}
              </button>
              {isSelected && <SelectionBadge />}
            </div>
          );

        default:
          return null;
      }
    },
    [selectedWidgetId, onSelectWidget, deviceMode]
  );

  const deviceConfig = {
    desktop: { width: "100%", height: "100%", bezel: "none" },
    tablet: { width: "768px", height: "90%", bezel: "none" },
    mobile: { width: "375px", height: "80%", bezel: "none" },
    iphone: { width: "390px", height: "844px", bezel: "iphone" },
    ipad: { width: "834px", height: "1112px", bezel: "ipad" },
    macbook: { width: "1280px", height: "800px", bezel: "macbook" },
  } as const;

  const currentConfig = deviceConfig[deviceMode];

  const handleDomainSubmit = () => {
    if (domainInput && onSetCustomDomain) {
      onSetCustomDomain(domainInput);
      setDomainInput("");
    }
  };

  return (
    <div
      className={`flex-1 bg-background p-4 flex flex-col items-center overflow-hidden relative transition-all duration-500 ${
        isFullscreen ? "fixed inset-0 z-[1000] p-0" : ""
      }`}
    >
      {!isFullscreen && (
        <div className="flex items-center gap-2 mb-4 bg-card p-1.5 rounded-2xl border border-border shrink-0">
          <DeviceButton active={deviceMode === "desktop"} onClick={() => setDeviceMode("desktop")} icon={<Monitor size={16} />} label="Desktop" />
          <DeviceButton active={deviceMode === "macbook"} onClick={() => setDeviceMode("macbook")} icon={<Monitor size={16} className="rotate-3" />} label="Macbook" />
          <DeviceButton active={deviceMode === "tablet"} onClick={() => setDeviceMode("tablet")} icon={<Tablet size={16} />} label="Tablet" />
          <DeviceButton active={deviceMode === "ipad"} onClick={() => setDeviceMode("ipad")} icon={<Tablet size={16} className="rotate-90" />} label="iPad" />
          <DeviceButton active={deviceMode === "mobile"} onClick={() => setDeviceMode("mobile")} icon={<Smartphone size={16} />} label="Mobile" />
          <DeviceButton active={deviceMode === "iphone"} onClick={() => setDeviceMode("iphone")} icon={<Smartphone size={16} className="scale-110" />} label="iPhone" />
          <div className="w-px h-4 bg-border mx-1" />
          <button
            onClick={() => setIsFullscreen(true)}
            className="p-2 text-muted-foreground hover:text-foreground hover:bg-accent rounded-lg transition-all"
            title="Fullscreen Preview"
          >
            <Maximize2 size={16} />
          </button>
        </div>
      )}

      {isFullscreen && (
        <button
          onClick={() => setIsFullscreen(false)}
          className="fixed top-6 right-6 z-[1100] bg-card text-foreground p-3 rounded-full shadow-2xl hover:bg-accent transition-all border border-border"
        >
          <Minimize2 size={24} />
        </button>
      )}

      {selectedComponent && onUpdateWidget && (
        <div className="absolute top-20 right-8 z-[200] w-72 bg-card/90 backdrop-blur-xl border border-border rounded-3xl shadow-2xl p-6 animate-in slide-in-from-right duration-300">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Settings size={16} className="text-primary" />
              <span className="text-xs font-black uppercase tracking-widest text-foreground">Properties</span>
            </div>
            <button onClick={() => onSelectWidget("")} className="p-1 text-muted-foreground hover:text-foreground transition-colors">
              <X size={16} />
            </button>
          </div>

          <div className="space-y-5">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-lg border border-border mb-4">
              <div className="w-2 h-2 bg-primary rounded-full" />
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-tighter">{selectedComponent.type}</span>
              <span className="text-[10px] text-muted-foreground ml-auto font-mono">#{String(selectedComponent.id).slice(0, 4)}</span>
            </div>

            {(selectedComponent.title !== undefined || selectedComponent.label !== undefined) && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <TypeIcon size={12} /> {selectedComponent.label ? "Label" : "Title"}
                </label>
                <input
                  type="text"
                  className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm text-foreground focus:border-primary outline-none transition-all"
                  value={selectedComponent.title || selectedComponent.label || ""}
                  onChange={(e) =>
                    onUpdateWidget(
                      selectedComponent.id,
                      selectedComponent.label ? { label: e.target.value } : { title: e.target.value }
                    )
                  }
                />
              </div>
            )}

            {(selectedComponent.subtitle !== undefined || selectedComponent.content !== undefined) && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <TypeIcon size={12} /> {selectedComponent.subtitle ? "Subtitle" : "Content"}
                </label>
                <textarea
                  className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm text-foreground focus:border-primary outline-none transition-all resize-none"
                  rows={3}
                  value={selectedComponent.subtitle || selectedComponent.content || ""}
                  onChange={(e) =>
                    onUpdateWidget(
                      selectedComponent.id,
                      selectedComponent.subtitle ? { subtitle: e.target.value } : { content: e.target.value }
                    )
                  }
                />
              </div>
            )}

            {selectedComponent.type === "CONTAINER" && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <LayoutIcon size={12} /> Columns
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4].map((num) => (
                    <button
                      key={num}
                      onClick={() => onUpdateWidget(selectedComponent.id, { columns: num })}
                      className={`flex-1 py-2 rounded-xl border text-xs font-bold transition-all ${
                        selectedComponent.columns === num
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background text-muted-foreground border-border hover:border-primary/50"
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-4 border-t border-border">
              <button
                onClick={() => onSelectWidget("")}
                className="w-full py-2.5 bg-muted text-muted-foreground rounded-xl text-xs font-bold hover:bg-accent transition-all flex items-center justify-center gap-2"
              >
                Done <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>
      )}

      <div
        className={`bg-card relative overflow-hidden flex flex-col border border-border transition-all duration-700 ease-in-out shadow-2xl ${
          isFullscreen ? "w-full h-full" : "rounded-2xl"
        }`}
        style={{
          width: isFullscreen ? "100%" : currentConfig.width,
          height: isFullscreen ? "100%" : currentConfig.height,
          borderRadius:
            currentConfig.bezel === "iphone" ? "48px" : currentConfig.bezel === "ipad" ? "32px" : isFullscreen ? "0" : "16px",
          borderWidth: currentConfig.bezel === "iphone" ? "12px" : currentConfig.bezel === "ipad" ? "16px" : "1px",
        }}
      >
        {currentConfig.bezel === "iphone" && (
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-7 bg-muted rounded-b-[20px] z-[120] flex items-center justify-center gap-3">
            <div className="w-2 h-2 rounded-full bg-background" />
            <div className="w-10 h-1 bg-background rounded-full" />
          </div>
        )}

        <div className="h-11 bg-muted border-b border-border flex items-center px-4 gap-3 shrink-0">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-background" />
            <div className="w-3 h-3 rounded-full bg-background" />
            <div className="w-3 h-3 rounded-full bg-background" />
          </div>
          <div className="flex-1 mx-6 bg-background rounded-md h-7 border border-border flex items-center px-3 text-[11px] text-muted-foreground font-medium overflow-hidden whitespace-nowrap">
            blink.cloud/{result.appName.toLowerCase().replace(/\s+/g, "-")}
          </div>
          <div className="text-[10px] font-bold text-primary whitespace-nowrap">LIVE SYNC</div>
        </div>

        {isDeploying && (
          <div className="absolute inset-0 z-[100] bg-background/95 backdrop-blur-xl flex flex-col items-center justify-center text-foreground text-center p-12">
            <div className="w-24 h-24 bg-primary rounded-[32px] flex items-center justify-center mb-8 shadow-2xl animate-bounce">
              <Rocket size={48} className="text-primary-foreground" />
            </div>
            <h2 className="text-3xl font-black mb-4">Deploying to Production...</h2>
            <p className="text-muted-foreground max-w-sm mb-12 font-medium">
              Blink compiles your interface and optimizes performance for an ultra-fast global deployment.
            </p>
            <div className="w-full max-w-md bg-muted h-3 rounded-full overflow-hidden mb-6 border border-border">
              <div className="bg-primary h-full transition-all duration-300" style={{ width: `${deploymentProgress}%` }} />
            </div>
            <div className="text-sm font-mono text-primary font-black tracking-widest">{deploymentProgress}% COMPLETE</div>
          </div>
        )}

        {deployedUrl && (
          <div className="absolute inset-0 z-[110] bg-background/80 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="bg-card rounded-[48px] p-12 max-w-2xl w-full shadow-2xl animate-in zoom-in duration-300 border border-border relative text-center">
              <button onClick={onCloseDeployModal} className="absolute top-8 right-8 text-muted-foreground hover:text-foreground">
                <X />
              </button>
              <div className="w-16 h-16 bg-primary/10 text-primary rounded-3xl flex items-center justify-center mx-auto mb-8">
                <CheckCircle2 size={32} />
              </div>
              <h2 className="text-3xl font-black text-foreground mb-2">Site Published!</h2>
              <p className="text-muted-foreground font-medium mb-10 text-sm">Your application is now live and publicly accessible.</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 text-left">
                <div className="bg-background p-6 rounded-3xl border border-border">
                  <h4 className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-4">Blink URL</h4>
                  <div className="flex items-center justify-between gap-4 group">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <Globe size={18} className="text-muted-foreground" />
                      <span className="text-foreground font-bold truncate text-sm">{deployedUrl}</span>
                    </div>
                    <a
                      href={deployedUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="bg-muted text-muted-foreground p-2 rounded-lg hover:text-foreground transition-colors"
                    >
                      <ExternalLink size={16} />
                    </a>
                  </div>
                </div>

                <div className="bg-background p-6 rounded-3xl border border-border">
                  <h4 className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-4">Custom Domain</h4>
                  {customDomain ? (
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <Link2 size={18} className="text-primary" />
                        <span className="text-foreground font-bold text-sm">{customDomain}</span>
                      </div>
                      <button onClick={() => onSetCustomDomain?.("")} className="text-[10px] font-bold text-destructive uppercase tracking-tighter">
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="example.com"
                        className="flex-1 bg-background border border-border rounded-xl px-3 py-1.5 text-xs text-foreground outline-none focus:border-primary"
                        value={domainInput}
                        onChange={(e) => setDomainInput(e.target.value)}
                      />
                      <button
                        onClick={handleDomainSubmit}
                        className="bg-primary text-primary-foreground px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:opacity-90"
                      >
                        Link
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <button className="py-4 bg-primary text-primary-foreground rounded-2xl font-black text-sm hover:opacity-90 transition-opacity">Copy URL</button>
                <button onClick={onCloseDeployModal} className="py-4 bg-muted text-foreground rounded-2xl font-black text-sm hover:bg-accent transition-all">
                  Back to Editor
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="flex-1 overflow-auto relative bg-background" onClick={() => onSelectWidget("")}
        >
          {isGenerating && (
            <div className="absolute inset-0 z-50 bg-background/70 backdrop-blur-md flex flex-col items-center justify-center animate-in fade-in">
              <Loader2 className="w-12 h-12 text-primary animate-spin" />
              <p className="mt-4 text-foreground font-black tracking-tight">AI is building...</p>
            </div>
          )}
          <div className="min-h-full pb-20">
            {result.components.length > 0 ? (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
                {result.components.map((comp: any) => renderComponent(comp))}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-12 text-center py-40">
                <h2 className="text-2xl font-black text-foreground mb-2">Projet Vide</h2>
                <p className="text-muted-foreground text-sm">Utilisez le chat pour générer votre interface.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const DeviceButton = ({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
      active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground hover:bg-accent"
    }`}
  >
    {icon}
    <span className="hidden xl:inline">{label}</span>
  </button>
);

const SelectionBadge = () => (
  <div className="absolute -top-3 -right-3 bg-primary text-primary-foreground p-1 rounded shadow-lg z-10 animate-in zoom-in">
    <Edit3 size={12} />
  </div>
);
