import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  MessageSquare,
  Code2,
  User,
  Bot,
  ArrowUp,
  PanelLeftClose,
  PanelLeftOpen,
  Sparkles,
  BrainCircuit,
} from "lucide-react";
import type { AppState } from "../types";

interface SidebarProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  onSend: (prompt?: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ state, setState, onSend }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<HTMLTextAreaElement>(null);

  const setIsCodeView = (val: boolean) => setState((prev) => ({ ...prev, isCodeView: val }));

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [state.history, state.isThinking]);

  useEffect(() => {
    if (!chatInputRef.current) return;
    chatInputRef.current.style.height = "auto";
    chatInputRef.current.style.height = `${Math.min(chatInputRef.current.scrollHeight, 240)}px`;
  }, [state.currentInput]);

  const handleSendClick = useCallback(() => {
    if (state.currentInput.trim()) onSend();
  }, [state.currentInput, onSend]);

  return (
    <div
      className={`flex flex-col border-r border-border bg-background text-muted-foreground text-sm h-full transition-all duration-300 ${
        isCollapsed ? "w-[64px]" : "w-[380px]"
      }`}
    >
      <div className="p-4 flex items-center justify-between shrink-0 overflow-hidden">
        {!isCollapsed && (
          <div className="flex items-center gap-2 text-foreground font-bold tracking-tight">
            <div className="w-5 h-5 bg-primary rounded-md" />
            <span>Blink AI</span>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1.5 hover:bg-accent rounded-lg transition-colors"
        >
          {isCollapsed ? <PanelLeftOpen size={18} /> : <PanelLeftClose size={18} />}
        </button>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        {!isCollapsed ? (
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
              {state.history.map((msg) => (
                <div key={msg.id} className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <div className="flex items-start gap-3">
                    <div
                      className={`shrink-0 w-6 h-6 rounded-md flex items-center justify-center ${
                        msg.role === "assistant"
                          ? "bg-primary/15 text-primary"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {msg.role === "assistant" ? <Bot size={14} /> : <User size={14} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-1">
                        {msg.role === "assistant" ? "Blink Engine" : "User"}
                      </div>
                      <div
                        className={`text-[13px] leading-relaxed ${
                          msg.role === "assistant" ? "text-foreground" : "text-muted-foreground"
                        }`}
                      >
                        {msg.content}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {state.isThinking && (
                <div className="animate-pulse flex items-start gap-3">
                  <div className="shrink-0 w-6 h-6 rounded-md bg-primary/15 text-primary flex items-center justify-center">
                    <BrainCircuit size={14} />
                  </div>
                  <div className="flex-1 bg-muted border border-border p-3 rounded-xl">
                    <div className="text-[10px] font-black text-primary uppercase tracking-widest mb-1">
                      Advanced Reasoning
                    </div>
                    <div className="text-[11px] text-muted-foreground italic">
                      Thinking about architecture and data flows...
                    </div>
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            <div className="p-4 bg-background border-t border-border">
              <div className="bg-muted border border-border rounded-2xl p-4">
                <textarea
                  ref={chatInputRef}
                  className="w-full bg-transparent border-none focus:ring-0 text-foreground placeholder:text-muted-foreground resize-none min-h-[40px] text-[13px] outline-none"
                  placeholder="Refine your SaaS build..."
                  value={state.currentInput}
                  onChange={(e) => setState((prev) => ({ ...prev, currentInput: e.target.value }))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendClick();
                    }
                  }}
                />
                <div className="flex items-center justify-between mt-2">
                  <button
                    type="button"
                    className="flex items-center gap-1.5 px-2.5 py-1.5 bg-background rounded-lg text-[10px] font-bold text-muted-foreground border border-border"
                  >
                    <Sparkles size={12} className="text-primary" /> reasoning
                  </button>
                  <button
                    onClick={handleSendClick}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                      state.currentInput.trim()
                        ? "bg-primary text-primary-foreground"
                        : "bg-background text-muted-foreground border border-border"
                    }`}
                  >
                    <ArrowUp size={18} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center py-6 gap-6">
            <button
              type="button"
              className={!state.isCodeView ? "text-primary" : "text-muted-foreground"}
              onClick={() => setIsCodeView(false)}
              title="Chat"
            >
              <MessageSquare size={20} />
            </button>
            <button
              type="button"
              className={state.isCodeView ? "text-primary" : "text-muted-foreground"}
              onClick={() => setIsCodeView(true)}
              title="Code"
            >
              <Code2 size={20} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
