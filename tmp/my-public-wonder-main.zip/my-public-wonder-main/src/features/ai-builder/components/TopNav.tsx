import React from "react";
import {
  Play,
  Cloud,
  Palette,
  Code,
  BarChart2,
  Plus,
  Maximize2,
  RotateCw,
  Github,
  Share2,
  Rocket,
  ArrowLeft,
  ShieldCheck,
  Loader2,
} from "lucide-react";

interface TopNavProps {
  onBackToLanding?: () => void;
  onPublish?: () => void;
  onUpgrade?: () => void;
  onRunSecurity?: () => void;
  onNewProject?: () => void;
  onToggleCodeView?: () => void;
  onOpenTheme?: () => void;
  isCodeView?: boolean;
  isGenerating?: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  onBackToLanding,
  onPublish,
  onUpgrade,
  onRunSecurity,
  onNewProject,
  onToggleCodeView,
  onOpenTheme,
  isCodeView,
  isGenerating,
}) => {
  return (
    <div className="h-[52px] border-b border-border bg-background flex items-center justify-between px-4 z-10 shrink-0">
      <div className="flex items-center gap-2">
        <button
          onClick={onBackToLanding}
          className="p-2 text-muted-foreground hover:text-foreground transition-colors"
          title="Back to Landing"
        >
          <ArrowLeft size={18} />
        </button>

        <button
          onClick={() => window.location.reload()}
          className="flex items-center gap-2 bg-primary text-primary-foreground px-3 py-1.5 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity active:scale-95"
        >
          {isGenerating ? (
            <Loader2 size={14} className="animate-spin" />
          ) : (
            <Play size={14} />
          )}
          Preview
        </button>

        <div className="h-4 w-px bg-border mx-1" />

        <div className="flex items-center gap-1">
          <IconButton onClick={onPublish} icon={<Cloud size={18} />} title="Cloud Publish" />
          <IconButton onClick={onOpenTheme} icon={<Palette size={18} />} title="Theme Engine" />
          <IconButton
            onClick={onToggleCodeView}
            icon={<Code size={18} />}
            title="Toggle Code View"
            active={isCodeView}
          />
          <IconButton onClick={onRunSecurity} icon={<BarChart2 size={18} />} title="Security Analysis" />
          <IconButton onClick={onNewProject} icon={<Plus size={18} />} title="New Project" />
        </div>
      </div>

      <div className="flex-1 flex justify-center px-4 max-w-xl">
        <div className="w-full bg-muted border border-border rounded-lg h-8 flex items-center px-3 gap-2 group cursor-text">
          <span className="text-xs text-muted-foreground">/editor</span>
          <div className="ml-auto flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Maximize2 size={12} className="text-muted-foreground" />
            <RotateCw size={12} className="text-muted-foreground" />
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={onRunSecurity}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-foreground/80 hover:bg-accent rounded-lg transition-all group"
          title="Run Security Scan"
        >
          <ShieldCheck size={16} className="group-hover:scale-110 transition-transform" />
          <span className="hidden lg:inline">Security</span>
        </button>

        <div className="flex items-center gap-2 mr-2">
          <div className="w-7 h-7 bg-primary rounded-full flex items-center justify-center text-[11px] font-bold text-primary-foreground">
            P
          </div>
          <button
            onClick={() => alert("Share Link copied!")}
            className="hidden sm:flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <Share2 size={14} />
            Share
          </button>
          <IconButton
            onClick={() => window.open("https://github.com", "_blank")}
            icon={<Github size={18} />}
            title="Open Github"
          />
        </div>

        <button
          onClick={onUpgrade}
          className="flex items-center gap-2 px-3 py-1.5 bg-muted border border-border rounded-lg text-xs font-medium text-foreground hover:bg-accent transition-colors"
        >
          <Rocket size={14} className="text-muted-foreground" />
          Upgrade
        </button>

        <button
          onClick={onPublish}
          className="px-4 py-1.5 bg-primary hover:opacity-90 text-primary-foreground rounded-lg text-sm font-medium transition-opacity active:scale-95"
        >
          Publish
        </button>
      </div>
    </div>
  );
};

const IconButton = ({
  icon,
  onClick,
  title,
  active,
}: {
  icon: React.ReactNode;
  onClick?: () => void;
  title?: string;
  active?: boolean;
}) => (
  <button
    onClick={onClick}
    title={title}
    className={`w-9 h-9 flex items-center justify-center rounded-lg transition-all ${
      active
        ? "bg-primary text-primary-foreground"
        : "text-muted-foreground hover:text-foreground hover:bg-accent"
    }`}
  >
    {icon}
  </button>
);
