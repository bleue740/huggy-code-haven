import React, { useState } from "react";
import { ArrowUp, ChevronRight, Sparkles, Zap } from "lucide-react";

interface LandingPageProps {
  onStart: (prompt: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  const [inputValue, setInputValue] = useState("");

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    onStart(inputValue || "Build a modern SaaS application");
  };

  return (
    <div className="fixed inset-0 z-[100] bg-background text-foreground overflow-y-auto">
      <nav className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur-md z-50 border-b border-border">
        <div className="flex items-center gap-12">
          <div className="text-2xl font-black tracking-tighter flex items-center gap-2 cursor-pointer">
            <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center text-primary-foreground">
              <Zap size={20} />
            </div>
            Blink
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => onStart("")}
            className="bg-primary text-primary-foreground px-7 py-3 rounded-2xl text-xs font-black uppercase tracking-widest hover:opacity-90 transition-opacity inline-flex items-center gap-2"
          >
            Get started <ChevronRight size={14} />
          </button>
        </div>
      </nav>

      <section className="max-w-5xl mx-auto pt-32 pb-32 px-6 flex flex-col items-center text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent text-[10px] font-black text-foreground uppercase tracking-[0.2em] mb-12 border border-border">
          <Sparkles size={12} className="text-primary" /> AI-Powered App Engine
        </div>
        <h1 className="text-5xl md:text-7xl font-black mb-10 tracking-tighter leading-[0.95]">
          Ship your vision <br />
          <span className="text-primary">at light speed.</span>
        </h1>
        <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mb-12 font-medium">
          Blink reasoning engine converts your thoughts into production software instantly.
        </p>

        <form onSubmit={handleSubmit} className="w-full max-w-3xl bg-card border border-border rounded-[32px] p-8 md:p-10 mb-20 shadow-2xl">
          <textarea
            className="w-full bg-transparent border-none focus:ring-0 text-xl md:text-2xl text-foreground placeholder:text-muted-foreground resize-none h-32 outline-none font-bold"
            placeholder="Build a dashboard with real-time analytics..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <div className="flex items-center justify-between mt-8 pt-8 border-t border-border">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">reasoning mode active</span>
            </div>
            <button
              type="submit"
              className="w-14 h-14 bg-primary text-primary-foreground rounded-2xl flex items-center justify-center hover:opacity-90 transition-opacity active:scale-95"
            >
              <ArrowUp size={28} />
            </button>
          </div>
        </form>
      </section>
    </div>
  );
};
