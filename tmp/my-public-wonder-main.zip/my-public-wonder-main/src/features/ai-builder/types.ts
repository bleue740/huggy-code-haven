export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}

export interface AISuggestion {
  id: string;
  label: string;
  description: string;
  prompt: string;
  icon: "layout" | "form" | "chart" | "button" | "table";
}

export interface UIComponent {
  id: string;
  type:
    | "HEADER"
    | "INPUT_FIELD"
    | "BUTTON"
    | "CARD"
    | "TEXT"
    | "CONTAINER"
    | "TABLE"
    | "CHART"
    | "NAVBAR";
  children?: UIComponent[];
  props?: Record<string, unknown>;
  actions?: Record<string, { type: string; payload?: unknown }>;
  // allow the JSON format to carry arbitrary fields
  [key: string]: unknown;
}

export interface SecurityResult {
  name: string;
  status: "passed" | "warning" | "info";
  description: string;
}

export interface AppState {
  credits: number;
  currentInput: string;
  isGenerating: boolean;
  isThinking: boolean;
  isCodeView: boolean;
  history: Message[];
  codeContent: string;
  suggestions: AISuggestion[];
  selectedWidgetId?: string;
  /** HSL triplet string, e.g. "221 83% 53%" */
  primaryColorHsl: string;
  // Deployment states
  isDeploying?: boolean;
  deploymentProgress?: number;
  deployedUrl?: string | null;
  customDomain?: string | null;
  // Modals
  showUpgradeModal?: boolean;
  showThemeModal?: boolean;
  // Security states
  isRunningSecurity?: boolean;
  showSecurityModal?: boolean;
  securityScore?: number;
  securityResults?: SecurityResult[];
}
