
import React, { useMemo, useCallback, useState, useEffect } from 'react';
import { 
  Loader2, 
  RefreshCcw, 
  AlertCircle, 
  Edit3, 
  Table as TableIcon, 
  BarChart, 
  Layout as LayoutIcon, 
  Home, 
  Menu, 
  Rocket, 
  ExternalLink, 
  X, 
  Globe, 
  CheckCircle2,
  Monitor,
  Tablet,
  Smartphone,
  Maximize2,
  Minimize2,
  Settings,
  ChevronRight,
  Type as TypeIcon,
  Palette as PaletteIcon,
  Link2,
  Sparkles
} from 'lucide-react';

interface PreviewAreaProps {
  isGenerating: boolean;
  isDeploying?: boolean;
  deploymentProgress?: number;
  deployedUrl?: string | null;
  customDomain?: string | null;
  codeContent: string;
  selectedWidgetId?: string;
  onSelectWidget: (id: string) => void;
  onCloseDeployModal?: () => void;
  onUpdateWidget?: (id: string, props: Record<string, any>) => void;
  onSetCustomDomain?: (domain: string) => void;
  isVisualEditMode?: boolean;
  onScreenshotCapture?: (dataUrl: string) => void;
}

type DeviceMode = 'desktop' | 'tablet' | 'mobile' | 'iphone' | 'ipad' | 'macbook';

export const PreviewArea: React.FC<PreviewAreaProps> = ({ 
  isGenerating, 
  isDeploying, 
  deploymentProgress = 0, 
  deployedUrl, 
  customDomain,
  codeContent, 
  selectedWidgetId, 
  onSelectWidget,
  onCloseDeployModal,
  onUpdateWidget,
  onSetCustomDomain,
  isVisualEditMode = false,
  onScreenshotCapture
}) => {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('desktop');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [domainInput, setDomainInput] = useState('');

  const result = useMemo(() => {
    try {
      const parsed = JSON.parse(codeContent);
      return { 
        valid: true, 
        components: parsed.components || [],
        appName: parsed.app_name || 'My App'
      };
    } catch (e) {
      return { valid: false, components: [], appName: 'Invalid JSON' };
    }
  }, [codeContent]);

  const selectedComponent = useMemo(() => {
    if (!selectedWidgetId) return null;
    const findRecursive = (components: any[]): any => {
      for (const comp of components) {
        if (comp.id === selectedWidgetId) return comp;
        if (comp.children) {
          const found = findRecursive(comp.children);
          if (found) return found;
        }
      }
      return null;
    };
    return findRecursive(result.components);
  }, [selectedWidgetId, result.components]);

  const renderComponent = useCallback((comp: any) => {
    if (!comp) return null;
    const isSelected = selectedWidgetId === comp.id;
    const baseClasses = `relative transition-all duration-200 cursor-pointer rounded-lg border-2 ${
      isSelected ? 'border-blue-500 ring-4 ring-blue-500/10' : 'border-transparent hover:border-blue-500/30'
    }`;

    const handleComponentClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      onSelectWidget(comp.id);
    };

    const children = comp.children?.map((child: any) => renderComponent(child));

    switch (comp.type) {
      case 'NAVBAR':
        return (
          <nav key={comp.id} onClick={handleComponentClick} className={`${baseClasses} bg-[#111] border-b border-white/5 px-6 py-4 flex items-center justify-between mb-6 sticky top-0 z-10 shadow-sm`}>
            <div className="flex items-center gap-2 font-bold text-white">
               <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-black">B</div>
               {comp.title || 'Blink App'}
            </div>
            <div className="flex gap-4 text-sm font-medium text-neutral-400">
               <span className="hover:text-blue-500">Dashboard</span>
               <span className="hover:text-blue-500">Settings</span>
            </div>
          </nav>
        );

      case 'CONTAINER':
        const cols = comp.columns || 1;
        const isSmall = deviceMode === 'mobile' || deviceMode === 'iphone';
        const isMed = deviceMode === 'tablet' || deviceMode === 'ipad';
        const responsiveCols = isSmall ? 1 : (isMed ? Math.min(cols, 2) : cols);
        return (
          <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} grid gap-6 mb-6 w-full px-6`} style={{ gridTemplateColumns: `repeat(${responsiveCols}, minmax(0, 1fr))` }}>
            {children}
            {isSelected && <SelectionBadge />}
          </div>
        );

      case 'HEADER':
        return (
          <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} mb-8 px-6 text-center md:text-left`}>
            <h1 className="text-3xl md:text-4xl font-black text-white tracking-tight leading-tight">{comp.title || 'Header'}</h1>
            {comp.subtitle && <p className="text-neutral-400 text-base md:text-lg mt-2 font-medium">{comp.subtitle}</p>}
            {isSelected && <SelectionBadge />}
          </div>
        );

      case 'CARD':
        return (
          <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} bg-[#111] p-6 rounded-2xl border border-white/5 shadow-sm`}>
            <div className="flex items-center justify-between mb-4">
               <h3 className="font-bold text-white text-lg">{comp.title || 'Card'}</h3>
               <LayoutIcon size={16} className="text-blue-500" />
            </div>
            <div className="text-neutral-400 text-sm leading-relaxed mb-4">{comp.content}</div>
            {children}
            {isSelected && <SelectionBadge />}
          </div>
        );

      case 'TABLE':
        const data = comp.data || [["Nom", "Status"]];
        return (
          <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} bg-[#111] rounded-2xl border border-white/5 shadow-sm overflow-hidden mb-8`}>
             <div className="overflow-x-auto">
               <table className="w-full text-left text-sm">
                 <thead className="bg-[#1a1a1a] border-b border-white/5">
                   <tr>{data[0]?.map((cell: any, i: number) => <th key={i} className="px-6 py-3 font-bold text-neutral-500 uppercase text-[10px] tracking-widest">{cell}</th>)}</tr>
                 </thead>
                 <tbody>
                   {data.slice(1).map((row: any, i: number) => (
                     <tr key={i} className="border-b border-white/5 hover:bg-white/5">
                       {row.map((cell: any, j: number) => <td key={j} className="px-6 py-4 text-neutral-300">{cell}</td>)}
                     </tr>
                   ))}
                 </tbody>
               </table>
             </div>
             {isSelected && <SelectionBadge />}
          </div>
        );

      case 'CHART':
        return (
          <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} bg-[#111] p-6 rounded-2xl border border-white/5 shadow-sm mb-6`}>
             <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-white">{comp.title || 'Graph'}</h3>
                <BarChart size={18} className="text-blue-500" />
             </div>
             <div className="h-32 flex items-end gap-2">
                {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
                  <div key={i} className="flex-1 bg-blue-600 rounded-t-md opacity-20" style={{ height: `${h}%` }}></div>
                ))}
             </div>
             {isSelected && <SelectionBadge />}
          </div>
        );

      case 'BUTTON':
        return (
          <div key={comp.id} onClick={handleComponentClick} className={`${baseClasses} inline-block mb-4`}>
            <button className={`px-6 py-3 rounded-xl font-bold text-sm bg-blue-600 text-white shadow-lg shadow-blue-500/20`}>
              {comp.label || 'Action'}
            </button>
            {isSelected && <SelectionBadge />}
          </div>
        );

      default: return null;
    }
  }, [selectedWidgetId, onSelectWidget, deviceMode]);

  const deviceConfig = {
    desktop: { width: '100%', height: '100%', bezel: 'none' },
    tablet: { width: '768px', height: '90%', bezel: 'none' },
    mobile: { width: '375px', height: '80%', bezel: 'none' },
    iphone: { width: '390px', height: '844px', bezel: 'iphone' },
    ipad: { width: '834px', height: '1112px', bezel: 'ipad' },
    macbook: { width: '1280px', height: '800px', bezel: 'macbook' }
  };

  const currentConfig = deviceConfig[deviceMode];

  const handleDomainSubmit = () => {
    if (domainInput && onSetCustomDomain) {
      onSetCustomDomain(domainInput);
      setDomainInput('');
    }
  };

  const handleCopyUrl = async () => {
    if (!deployedUrl) return;
    try {
      await navigator.clipboard.writeText(deployedUrl);
    } catch {
      // ignore
    }
  };

  return (
    <div className={`flex-1 bg-background p-4 flex flex-col items-center overflow-hidden relative transition-all duration-500 ${isFullscreen ? 'fixed inset-0 z-[1000] p-0' : ''}`}>
      
      {/* Device Toggle Bar */}
      {!isFullscreen && (
          <div className="flex items-center gap-2 mb-4 bg-card p-1.5 rounded-2xl border border-border shrink-0 shadow-2xl">
          <DeviceButton 
            active={deviceMode === 'desktop'} 
            onClick={() => setDeviceMode('desktop')} 
            icon={<Monitor size={16} />} 
            label="Desktop"
          />
          <DeviceButton 
            active={deviceMode === 'macbook'} 
            onClick={() => setDeviceMode('macbook')} 
            icon={<Monitor size={16} className="rotate-3" />} 
            label="Macbook"
          />
          <DeviceButton 
            active={deviceMode === 'tablet'} 
            onClick={() => setDeviceMode('tablet')} 
            icon={<Tablet size={16} />} 
            label="Tablet"
          />
          <DeviceButton 
            active={deviceMode === 'ipad'} 
            onClick={() => setDeviceMode('ipad')} 
            icon={<Tablet size={16} className="rotate-90" />} 
            label="iPad"
          />
          <DeviceButton 
            active={deviceMode === 'mobile'} 
            onClick={() => setDeviceMode('mobile')} 
            icon={<Smartphone size={16} />} 
            label="Mobile"
          />
           <DeviceButton 
            active={deviceMode === 'iphone'} 
            onClick={() => setDeviceMode('iphone')} 
            icon={<Smartphone size={16} className="scale-110" />} 
            label="iPhone"
          />
          <div className="w-[1px] h-4 bg-white/10 mx-1"></div>
          <button 
            onClick={() => setIsFullscreen(true)}
            className="p-2 text-neutral-400 hover:text-white hover:bg-white/5 rounded-lg transition-all"
            title="Fullscreen Preview"
          >
            <Maximize2 size={16} />
          </button>
        </div>
      )}

      {/* Fullscreen Exit Button */}
      {isFullscreen && (
        <button 
          onClick={() => setIsFullscreen(false)}
          className="fixed top-6 right-6 z-[1100] bg-white text-slate-900 p-3 rounded-full shadow-2xl hover:bg-blue-50 transition-all border border-slate-200"
        >
          <Minimize2 size={24} />
        </button>
      )}

      {/* Property Editor Panel (Floating) */}
      {selectedComponent && onUpdateWidget && (
        <div className="absolute top-20 right-8 z-[200] w-72 bg-[#111]/90 backdrop-blur-xl border border-white/10 rounded-3xl shadow-[0_32px_64px_rgba(0,0,0,0.5)] p-6 animate-in slide-in-from-right duration-300">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Settings size={16} className="text-blue-500" />
              <span className="text-xs font-black uppercase tracking-widest text-white">Properties</span>
            </div>
            <button onClick={() => onSelectWidget('')} className="p-1 text-neutral-500 hover:text-white transition-colors"><X size={16} /></button>
          </div>
          
          <div className="space-y-5">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg border border-white/5 mb-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-tighter">{selectedComponent.type}</span>
              <span className="text-[10px] text-neutral-600 ml-auto font-mono">#{selectedComponent.id.slice(0, 4)}</span>
            </div>

            {/* Title Property */}
            {(selectedComponent.title !== undefined || selectedComponent.label !== undefined) && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest flex items-center gap-2">
                  <TypeIcon size={12} /> {selectedComponent.label ? 'Label' : 'Title'}
                </label>
                <input 
                  type="text" 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:border-blue-500 outline-none transition-all"
                  value={selectedComponent.title || selectedComponent.label || ''}
                  onChange={(e) => onUpdateWidget(selectedComponent.id, selectedComponent.label ? { label: e.target.value } : { title: e.target.value })}
                />
              </div>
            )}

            {/* Subtitle / Content Property */}
            {(selectedComponent.subtitle !== undefined || selectedComponent.content !== undefined) && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest flex items-center gap-2">
                   <TypeIcon size={12} /> {selectedComponent.subtitle ? 'Subtitle' : 'Content'}
                </label>
                <textarea 
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:border-blue-500 outline-none transition-all resize-none"
                  rows={3}
                  value={selectedComponent.subtitle || selectedComponent.content || ''}
                  onChange={(e) => onUpdateWidget(selectedComponent.id, selectedComponent.subtitle ? { subtitle: e.target.value } : { content: e.target.value })}
                />
              </div>
            )}

            {/* Container Specific: Columns */}
            {selectedComponent.type === 'CONTAINER' && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest flex items-center gap-2">
                   <LayoutIcon size={12} /> Columns
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4].map(num => (
                    <button 
                      key={num}
                      onClick={() => onUpdateWidget(selectedComponent.id, { columns: num })}
                      className={`flex-1 py-2 rounded-xl border text-xs font-bold transition-all ${selectedComponent.columns === num ? 'bg-blue-600 text-white border-blue-500' : 'bg-black/40 text-neutral-400 border-white/10 hover:border-blue-500/50'}`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-4 border-t border-white/5">
               <button 
                 onClick={() => onSelectWidget('')}
                 className="w-full py-2.5 bg-white/5 text-neutral-400 rounded-xl text-xs font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-2"
               >
                 Done <ChevronRight size={14} />
               </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Frame Container */}
      <div 
        className={`bg-background relative overflow-hidden flex flex-col border border-border transition-all duration-700 ease-in-out shadow-[0_0_100px_rgba(0,0,0,0.8)] ${isFullscreen ? 'w-full h-full' : 'rounded-2xl'}`}
        style={{ 
          width: isFullscreen ? '100%' : currentConfig.width,
          height: isFullscreen ? '100%' : currentConfig.height,
          borderRadius: currentConfig.bezel === 'iphone' ? '48px' : (currentConfig.bezel === 'ipad' ? '32px' : (isFullscreen ? '0' : '16px')),
          borderWidth: currentConfig.bezel === 'iphone' ? '12px' : (currentConfig.bezel === 'ipad' ? '16px' : '1px'),
          borderColor: `hsl(var(--border))`,
        }}
      >
        {/* Notch for iPhone */}
        {currentConfig.bezel === 'iphone' && (
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-7 bg-[#1a1a1a] rounded-b-[20px] z-[120] flex items-center justify-center gap-3">
             <div className="w-2 h-2 rounded-full bg-neutral-800"></div>
             <div className="w-10 h-1 bg-neutral-800 rounded-full"></div>
          </div>
        )}
        
        {/* Mock Browser Bar */}
         <div className="h-11 bg-secondary border-b border-border flex items-center px-4 gap-3 shrink-0">
           <div className="flex gap-1.5"><div className="w-3 h-3 rounded-full bg-[#333]"></div><div className="w-3 h-3 rounded-full bg-[#333]"></div><div className="w-3 h-3 rounded-full bg-[#333]"></div></div>
           <div className="flex-1 mx-6 bg-black/40 rounded-md h-7 border border-white/5 flex items-center px-3 text-[11px] text-neutral-500 font-medium overflow-hidden whitespace-nowrap">
              blink.cloud/{result.appName.toLowerCase().replace(/\s+/g, '-')}
           </div>
           <div className="text-[10px] font-bold text-blue-500 whitespace-nowrap">LIVE SYNC</div>
        </div>

        {/* Deploying Overlay */}
        {isDeploying && (
          <div className="absolute inset-0 z-[100] bg-[#050505]/95 backdrop-blur-xl flex flex-col items-center justify-center text-white text-center p-12">
             <div className="w-24 h-24 bg-blue-600 rounded-[32px] flex items-center justify-center mb-8 shadow-2xl shadow-blue-500/40 animate-bounce">
                <Rocket size={48} className="text-white" />
             </div>
             <h2 className="text-3xl font-black mb-4">Deploying to Production...</h2>
             <p className="text-neutral-400 max-w-sm mb-12 font-medium">Blink compiles your interface and optimizes performance for an ultra-fast global deployment.</p>
             <div className="w-full max-w-md bg-white/10 h-3 rounded-full overflow-hidden mb-6 border border-white/5">
                <div className="bg-blue-600 h-full transition-all duration-300" style={{ width: `${deploymentProgress}%` }}></div>
             </div>
             <div className="text-sm font-mono text-blue-400 font-black tracking-widest">{deploymentProgress}% COMPLETE</div>
          </div>
        )}

        {/* Deployed Success Modal */}
        {deployedUrl && (
          <div className="absolute inset-0 z-[110] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6">
             <div className="bg-[#111] rounded-[48px] p-12 max-w-2xl w-full shadow-[0_0_100px_rgba(0,0,0,1)] animate-in zoom-in duration-300 border border-white/10 relative text-center">
                <button onClick={onCloseDeployModal} className="absolute top-8 right-8 text-neutral-500 hover:text-white"><X /></button>
                <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-sm">
                   <CheckCircle2 size={32} />
                </div>
                <h2 className="text-3xl font-black text-white mb-2">Site Published!</h2>
                <p className="text-neutral-400 font-medium mb-10 text-sm">Your application is now live and publicly accessible.</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 text-left">
                   <div className="bg-black/50 p-6 rounded-3xl border border-white/5">
                      <h4 className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-4">Blink URL</h4>
                      <div className="flex items-center justify-between gap-4 group">
                         <div className="flex items-center gap-3 overflow-hidden">
                            <Globe size={18} className="text-neutral-600" />
                            <span className="text-white font-bold truncate text-sm">{deployedUrl}</span>
                         </div>
                         <a href={deployedUrl} target="_blank" className="bg-white/5 text-neutral-400 p-2 rounded-lg hover:text-white transition-colors"><ExternalLink size={16} /></a>
                      </div>
                   </div>

                   <div className="bg-black/50 p-6 rounded-3xl border border-white/5">
                      <h4 className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-4">Custom Domain</h4>
                      {customDomain ? (
                        <div className="flex items-center justify-between gap-4">
                           <div className="flex items-center gap-3">
                              <Link2 size={18} className="text-blue-500" />
                              <span className="text-white font-bold text-sm">{customDomain}</span>
                           </div>
                           <button onClick={() => onSetCustomDomain?.('')} className="text-[10px] font-bold text-red-500 hover:text-red-400 uppercase tracking-tighter">Remove</button>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                           <input 
                             type="text" 
                             placeholder="example.com"
                             className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white outline-none focus:border-blue-500"
                             value={domainInput}
                             onChange={(e) => setDomainInput(e.target.value)}
                           />
                           <button 
                             onClick={handleDomainSubmit}
                             className="bg-blue-600 text-white px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-500"
                           >
                             Link
                           </button>
                        </div>
                      )}
                   </div>
                </div>

                 <div className="grid grid-cols-2 gap-4">
                    <button onClick={handleCopyUrl} className="py-4 bg-white text-black rounded-2xl font-black text-sm hover:bg-neutral-200 transition-all">Copy URL</button>
                   <button onClick={onCloseDeployModal} className="py-4 bg-white/5 text-white rounded-2xl font-black text-sm hover:bg-white/10 transition-all">Back to Editor</button>
                </div>
             </div>
          </div>
        )}

        {/* Dynamic Canvas */}
         <div 
           className={`flex-1 overflow-auto relative bg-background ${isVisualEditMode ? 'cursor-crosshair' : ''}`} 
           onClick={() => onSelectWidget('')}
         >
          {/* Visual Edit Mode Overlay */}
          {isVisualEditMode && (
            <div className="absolute inset-0 z-[45] pointer-events-none">
              <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg animate-pulse flex items-center gap-2">
                <Sparkles size={14} />
                Visual Edit Mode — Click any element to edit
              </div>
              {/* Subtle border overlay */}
              <div className="absolute inset-0 border-2 border-blue-500/30 rounded-lg m-2" />
            </div>
          )}

          {isGenerating && (
            <div className="absolute inset-0 z-50 bg-[#0d0d0d]/70 backdrop-blur-md flex flex-col items-center justify-center animate-in fade-in">
               <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
               <p className="mt-4 text-white font-black tracking-tight">AI is building...</p>
            </div>
          )}
          <div className="min-h-full pb-20">
             {result.components.length > 0 ? (
               <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
                  {result.components.map((comp: any) => renderComponent(comp))}
               </div>
             ) : (
               <div className="h-full flex flex-col items-center justify-center p-12 text-center py-40">
                  <h2 className="text-2xl font-black text-white mb-2">Projet Vide</h2>
                  <p className="text-neutral-500 text-sm">Utilisez le chat pour générer votre interface.</p>
               </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

type DeviceButtonProps = {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
} & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'onClick'>;

// Radix/Slot-like wrappers can attach refs to children; forwardRef prevents "Function components cannot be given refs".
const DeviceButton = React.forwardRef<HTMLButtonElement, DeviceButtonProps>(
  ({ active, onClick, icon, label, ...props }, ref) => (
    <button
      ref={ref}
      onClick={onClick}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${active ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'text-neutral-400 hover:text-white hover:bg-white/5'}`}
      {...props}
    >
      {icon}
      <span className="hidden xl:inline">{label}</span>
    </button>
  )
);

DeviceButton.displayName = 'DeviceButton';

const SelectionBadge = () => (
  <div className="absolute -top-3 -right-3 bg-blue-600 text-white p-1 rounded shadow-lg z-10 animate-in zoom-in"><Edit3 size={12} /></div>
);
