
import React, { useState } from 'react';
import { 
  Plus, 
  Zap, 
  Palette, 
  Globe, 
  Mic, 
  ArrowUp, 
  Layout, 
  Calendar, 
  Briefcase, 
  RefreshCw,
  Code2,
  Cpu,
  ShieldCheck,
  ChevronRight,
  Github,
  Twitter,
  Linkedin,
  Rocket,
  CheckCircle2,
  Smartphone,
  Menu,
  X,
  Sparkles
} from 'lucide-react';

interface LandingPageProps {
  onStart: (prompt: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  const [inputValue, setInputValue] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const suggestions = [
    { icon: <Layout size={14} className="text-blue-500" />, text: "AI Landing Page Builder" },
    { icon: <Zap size={14} className="text-orange-500" />, text: "SaaS Dashboard for Analytics" },
    { icon: <Calendar size={14} className="text-blue-600" />, text: "Booking System for Doctors" },
    { icon: <Briefcase size={14} className="text-emerald-500" />, text: "Project Management Tool" },
  ];

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (inputValue.trim()) {
      onStart(inputValue);
    } else {
      onStart("Build a modern SaaS application with analytics");
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-['Inter',sans-serif] selection:bg-blue-600/30 overflow-x-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 right-0 h-[1000px] pointer-events-none overflow-hidden -z-10">
        <div className="absolute top-[-200px] left-1/2 -translate-x-1/2 w-[1400px] h-[800px] bg-gradient-to-b from-blue-900/20 via-transparent to-transparent blur-[120px]"></div>
      </div>

      {/* Navbar */}
      <nav className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between sticky top-0 bg-[#050505]/80 backdrop-blur-md z-50 border-b border-white/5">
        <div className="flex items-center gap-12">
          <div 
            className="text-2xl font-black tracking-tighter flex items-center gap-2 cursor-pointer group"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Zap size={20} fill="currentColor" />
            </div>
            Blink
          </div>
          <div className="hidden lg:flex items-center gap-8 text-[14px] font-bold text-neutral-400">
            <button onClick={() => scrollToSection('features')} className="hover:text-white transition-colors">Features</button>
            <button onClick={() => scrollToSection('how-it-works')} className="hover:text-white transition-colors">How it works</button>
            <button onClick={() => scrollToSection('pricing')} className="hover:text-white transition-colors">Pricing</button>
            <a href="#" className="hover:text-white transition-colors">Docs</a>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button className="hidden sm:block text-[14px] font-bold text-neutral-400 hover:text-white px-4">Log in</button>
          <button 
            onClick={() => onStart("")}
            className="bg-white text-black px-7 py-3 rounded-2xl text-[14px] font-[800] shadow-xl shadow-white/5 hover:bg-neutral-200 transition-all active:scale-95 flex items-center gap-2"
          >
            Get started for free <ChevronRight size={16} />
          </button>
          <button className="lg:hidden p-2 text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-[#050505] pt-24 px-6 animate-in slide-in-from-top duration-300">
           <div className="flex flex-col gap-8 text-2xl font-black">
              <button onClick={() => scrollToSection('features')} className="text-left">Features</button>
              <button onClick={() => scrollToSection('how-it-works')} className="text-left">How it works</button>
              <button onClick={() => scrollToSection('pricing')} className="text-left">Pricing</button>
              <button onClick={() => onStart("")} className="bg-white text-black py-4 rounded-2xl text-center">Start Building</button>
           </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="max-w-5xl mx-auto pt-20 pb-32 px-6 flex flex-col items-center text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 text-[12px] font-black text-blue-400 uppercase tracking-[0.15em] mb-12 border border-blue-500/20 shadow-sm">
          <Sparkles size={14} /> AI-POWERED APP BUILDER
        </div>
        
        <h1 className="text-6xl md:text-[110px] font-black mb-12 tracking-tight leading-[0.85] text-white">
          Build any SaaS <br />
          <span className="italic text-blue-500 font-medium">instantly.</span>
        </h1>

        <p className="text-neutral-400 text-xl md:text-2xl max-w-3xl mb-16 leading-relaxed font-medium">
          Describe your project, Blink does the rest. AI-generated code, UI, dashboards, and data tables in seconds.
        </p>

        {/* Prompt Input Box */}
        <div className="w-full max-w-4xl bg-[#111] border border-white/5 rounded-[40px] shadow-[0_40px_80px_rgba(0,0,0,0.5)] p-8 md:p-10 mb-20 group transition-all hover:border-blue-500/30 focus-within:ring-8 focus-within:ring-blue-500/5">
          <textarea 
            className="w-full bg-transparent border-none focus:ring-0 text-2xl md:text-3xl text-white placeholder-neutral-700 resize-none h-40 scrollbar-none outline-none font-bold leading-tight"
            placeholder="Build a CRM for real estate with client tracking..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSubmit())}
          />
          <div className="flex items-center justify-between mt-8 pt-8 border-t border-white/5">
            <div className="flex items-center gap-6">
              <button className="text-neutral-500 hover:text-white transition-colors"><Plus size={28} /></button>
              <div className="hidden sm:flex items-center gap-3">
                 <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                 <span className="text-[13px] font-black text-neutral-500 uppercase tracking-widest">Advanced Model Active</span>
              </div>
            </div>
            <button 
              onClick={() => handleSubmit()}
              className="w-16 h-16 bg-blue-600 text-white rounded-[24px] flex items-center justify-center shadow-2xl shadow-blue-500/40 hover:bg-blue-500 hover:scale-110 transition-all active:scale-95"
            >
              <ArrowUp size={32} strokeWidth={3} />
            </button>
          </div>
        </div>

        {/* Suggestions Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full">
          {suggestions.map((item, idx) => (
            <button 
              key={idx}
              onClick={() => onStart(item.text)}
              className="flex flex-col items-center gap-4 px-6 py-8 bg-[#111] border border-white/5 rounded-[32px] hover:border-blue-500/50 hover:bg-[#161616] transition-all shadow-sm group"
            >
              <div className="p-4 bg-white/5 rounded-2xl group-hover:scale-110 transition-transform group-hover:bg-white/10">
                {item.icon}
              </div>
              <span className="text-[14px] font-black text-white">{item.text}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 border-y border-white/5 bg-white/2">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
           <div>
              <div className="text-5xl font-black text-white mb-2 tracking-tight">10k+</div>
              <p className="text-neutral-500 text-xs font-black uppercase tracking-widest">Active Creators</p>
           </div>
           <div>
              <div className="text-5xl font-black text-white mb-2 tracking-tight">4.8s</div>
              <p className="text-neutral-500 text-xs font-black uppercase tracking-widest">Generation Time</p>
           </div>
           <div>
              <div className="text-5xl font-black text-white mb-2 tracking-tight">100%</div>
              <p className="text-neutral-500 text-xs font-black uppercase tracking-widest">Code Ownership</p>
           </div>
           <div>
              <div className="text-5xl font-black text-white mb-2 tracking-tight">Unlimited</div>
              <p className="text-neutral-500 text-xs font-black uppercase tracking-widest">Scalability</p>
           </div>
        </div>
      </section>

      {/* Features Detail */}
      <section id="features" className="py-40 max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-24">
           <h2 className="text-5xl font-black mb-6 tracking-tight">The ultimate AI engine.</h2>
           <p className="text-neutral-400 font-medium text-lg leading-relaxed">Blink combines the most powerful language models with a robust design system for impeccable results.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
           <FeatureCard 
             icon={<Code2 size={24} />} 
             title="Instant Clean Code" 
             description="We generate production-ready React and Tailwind code. Zero compromises on quality."
           />
           <FeatureCard 
             icon={<Palette size={24} />} 
             title="Design System" 
             description="Every component follows strict design tokens for perfect visual consistency."
           />
           <FeatureCard 
             icon={<Smartphone size={24} />} 
             title="Full Responsive" 
             description="Your apps look stunning on desktop, tablet, and mobile with zero extra effort."
           />
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-40 max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-5xl font-black mb-6 tracking-tight">Simple Pricing.</h2>
          <p className="text-neutral-400 font-bold">Choose the plan that matches your ambition.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
           <PricingCard 
             tier="Starter" 
             price="0" 
             features={["3 active projects", "AI base models", "Community support"]}
             onSelect={() => onStart("")}
           />
           <PricingCard 
             tier="Pro" 
             price="29" 
             popular
             features={["Unlimited projects", "Blink-Ultra-3 AI", "Private deployments", "Custom domains", "Priority support"]}
             onSelect={() => onStart("")}
           />
           <PricingCard 
             tier="Enterprise" 
             price="99" 
             features={["Custom models", "Advanced security", "SSO integration", "Dedicated manager"]}
             onSelect={() => onStart("")}
           />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#050505] pt-32 pb-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-5 gap-16 mb-24">
           <div className="col-span-2">
              <div className="text-3xl font-black tracking-tighter flex items-center gap-3 mb-10 text-white">
                <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center text-white"><Zap size={24} fill="currentColor" /></div>
                Blink
              </div>
              <p className="text-neutral-500 max-w-sm mb-10 font-bold leading-relaxed text-lg">The world's first AI-native software generation engine. Built for visionaries.</p>
              <div className="flex gap-6">
                 <FooterSocial icon={<Twitter size={24} />} />
                 <FooterSocial icon={<Github size={24} />} />
                 <FooterSocial icon={<Linkedin size={24} />} />
              </div>
           </div>
           <div>
             <h4 className="font-black text-white mb-8 uppercase text-xs tracking-[0.2em]">Product</h4>
             <ul className="space-y-5 text-neutral-500 font-bold">
                <li><button onClick={() => scrollToSection('features')} className="hover:text-white">Features</button></li>
                <li><a href="#" className="hover:text-white">Templates</a></li>
                <li><button onClick={() => scrollToSection('pricing')} className="hover:text-white">Pricing</button></li>
                <li><a href="#" className="hover:text-white">API</a></li>
             </ul>
           </div>
           <div>
             <h4 className="font-black text-white mb-8 uppercase text-xs tracking-[0.2em]">Company</h4>
             <ul className="space-y-5 text-neutral-500 font-bold">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
             </ul>
           </div>
           <div>
             <h4 className="font-black text-white mb-8 uppercase text-xs tracking-[0.2em]">Legal</h4>
             <ul className="space-y-5 text-neutral-500 font-bold">
                <li><a href="#" className="hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-white">Terms</a></li>
                <li><a href="#" className="hover:text-white">License</a></li>
             </ul>
           </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-10">
           <p className="text-neutral-600 text-sm font-bold tracking-tight">© 2025 Blink AI Inc. All rights reserved.</p>
           <div className="flex gap-10 text-sm font-bold text-neutral-600">
              <span className="cursor-pointer hover:text-white">Terms</span>
              <span className="cursor-pointer hover:text-white">Privacy</span>
              <span className="cursor-pointer hover:text-white">Cookies</span>
           </div>
        </div>
      </footer>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="p-12 bg-[#111] border border-white/5 rounded-[48px] hover:border-blue-500/50 hover:shadow-2xl transition-all group hover:-translate-y-2">
    <div className="w-16 h-16 bg-blue-500/10 text-blue-500 rounded-3xl flex items-center justify-center mb-10 transition-transform group-hover:scale-110 group-hover:rotate-6">
      {icon}
    </div>
    <h3 className="text-3xl font-black text-white mb-6 tracking-tight">{title}</h3>
    <p className="text-neutral-500 leading-relaxed font-bold text-lg">{description}</p>
  </div>
);

const PricingCard = ({ tier, price, features, popular, onSelect }: any) => (
  <div className={`p-12 rounded-[48px] border flex flex-col transition-all hover:scale-[1.02] ${popular ? 'bg-blue-600 text-white border-blue-500 shadow-2xl relative' : 'bg-[#111] border-white/5 text-white'}`}>
    {popular && <div className="absolute top-6 right-6 bg-white text-blue-600 text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full">Most Popular</div>}
    <div className="mb-10">
      <h4 className="text-xl font-black mb-4">{tier}</h4>
      <div className="flex items-baseline gap-2 mb-6">
        <span className="text-5xl font-black">${price}</span>
        <span className="text-sm font-bold opacity-60">/month</span>
      </div>
    </div>
    <div className="space-y-5 mb-12 flex-1">
      {features.map((f: string, i: number) => (
        <div key={i} className="flex items-center gap-3">
          <CheckCircle2 size={20} className={popular ? 'text-blue-100' : 'text-blue-500'} />
          <span className="font-bold text-sm tracking-tight">{f}</span>
        </div>
      ))}
    </div>
    <button 
      onClick={onSelect}
      className={`w-full py-5 rounded-[24px] font-black text-lg transition-all active:scale-95 ${popular ? 'bg-white text-blue-600 hover:bg-neutral-100' : 'bg-white/5 text-white hover:bg-white/10'}`}
    >
      Choose {tier}
    </button>
  </div>
);

const FooterSocial = ({ icon }: { icon: React.ReactNode }) => (
  <a href="#" className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-neutral-500 hover:bg-blue-600 hover:text-white transition-all hover:scale-110 shadow-sm">
    {icon}
  </a>
);
