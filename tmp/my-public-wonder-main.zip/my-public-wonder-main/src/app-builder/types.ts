
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface AISuggestion {
  id: string;
  label: string;
  description: string;
  prompt: string;
  icon: 'layout' | 'form' | 'chart' | 'button' | 'table';
}

export interface UIComponent {
  id: string;
  type: 'HEADER' | 'INPUT_FIELD' | 'BUTTON' | 'CARD' | 'TEXT' | 'CONTAINER' | 'TABLE' | 'CHART' | 'NAVBAR';
  children?: UIComponent[];
  props?: Record<string, any>;
  actions?: Record<string, { type: string; payload?: any }>;
  [key: string]: any;
}

export interface SecurityResult {
  name: string;
  status: 'passed' | 'warning' | 'info';
  description: string;
}

export interface AIEvent {
  id: string;
  type: 'status' | 'tool' | 'error';
  text: string;
  timestamp: number;
}

export interface AppState {
  projectId?: string;
  credits: number;
  currentInput: string;
  isGenerating: boolean;
  /** Short user-facing status (no internal reasoning). */
  aiStatusText?: string | null;
  /** Short event log (status/tool/error) for the current run. */
  aiEvents?: AIEvent[];
  isCodeView: boolean; // Lifted state
  history: Message[];
  /** Multi-file virtual file system: filename → code */
  files: Record<string, string>;
  /** Currently active/editing file */
  activeFile: string;
  suggestions: AISuggestion[];
  selectedWidgetId?: string;
  // Visual Edit Mode (lifted state)
  isVisualEditMode?: boolean;
  // Screenshot attachment
  screenshotAttachment?: string | null;
  // History modal
  showHistoryModal?: boolean;
  // Deployment states
  isDeploying?: boolean;
  deploymentProgress?: number;
  deployedUrl?: string | null;
  customDomain?: string | null;
  deploymentHistory?: { id: string; url: string; created_at: string }[];
  // Upgrade states
  showUpgradeModal?: boolean;
  // Security states
  isRunningSecurity?: boolean;
  showSecurityModal?: boolean;
  securityScore?: number;
  securityResults?: SecurityResult[];
}
