import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import { Sidebar } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { CodePreview } from './components/CodePreview';
import { LandingPage } from './components/LandingPage';
import { ConsolePanel } from './components/ConsolePanel';
import { useConsoleCapture } from './hooks/useConsoleCapture';
import { useCredits } from './hooks/useCredits';
import { AppState, Message, AISuggestion, SecurityResult } from './types';
import { X, CheckCircle2, Zap, Rocket, ShieldCheck, AlertTriangle, Info, Loader2, History } from 'lucide-react';
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
const DEFAULT_APP_CODE = `const { useState, useEffect, useCallback, useRef } = React;

function App() {
  return (
    <div className="min-h-screen bg-[#050505] text-white flex items-center justify-center p-8">
      <div className="text-center max-w-2xl">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-8">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
        </div>
        <h1 className="text-5xl font-black tracking-tight mb-4">Blink AI</h1>
        <p className="text-neutral-400 text-lg mb-8">Décris l'application que tu veux construire dans le chat. L'IA va générer du vrai code React pour toi.</p>
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600/20 text-blue-400 text-sm font-bold rounded-full border border-blue-500/30">
          <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
          Prêt à générer
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App));
`;

const DEFAULT_FILES: Record<string, string> = { 'App.tsx': DEFAULT_APP_CODE };

// --- Helpers ---

function buildConcatenatedCode(files: Record<string, string>): string {
  const entries = Object.entries(files);
  const app = entries.find(([n]) => n === 'App.tsx');
  const others = entries.filter(([n]) => n !== 'App.tsx').sort(([a], [b]) => a.localeCompare(b));
  return [...others.map(([, c]) => c), app?.[1] ?? ''].join('\n\n');
}

function serializeFiles(files: Record<string, string>): string {
  if (Object.keys(files).length === 1 && files['App.tsx']) return files['App.tsx'];
  return JSON.stringify({ __multifile: true, files });
}

function deserializeFiles(raw: string | null | undefined): Record<string, string> {
  if (!raw) return { ...DEFAULT_FILES };
  try {
    const parsed = JSON.parse(raw);
    if (parsed?.__multifile && typeof parsed.files === 'object') return parsed.files;
    return { 'App.tsx': raw };
  } catch {
    return { 'App.tsx': raw };
  }
}

const App: React.FC = () => {
  const navigate = useNavigate();
  const [showLanding, setShowLanding] = useState(true);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  
  // Console capture hook
  const { logs: consoleLogs, clearLogs: clearConsoleLogs } = useConsoleCapture();
  
  // Credits hook
  const { credits, useCredits: deductCredits, isLoading: creditsLoading } = useCredits();
  
  const [state, setState] = useState<AppState>({
    credits: 0,
    currentInput: '',
    isGenerating: false,
    aiStatusText: null,
    aiEvents: [],
    isCodeView: false,
    history: [{
      id: '1',
      role: 'assistant',
      content: "Je suis prêt. Décrivez-moi l'application que vous voulez construire — je vais générer du vrai code React multi-fichiers.",
      timestamp: Date.now(),
    }],
    suggestions: [],
    files: { ...DEFAULT_FILES },
    activeFile: 'App.tsx',
    isDeploying: false,
    deploymentProgress: 0,
    deployedUrl: null,
    customDomain: null,
    showUpgradeModal: false,
    isRunningSecurity: false,
    showSecurityModal: false,
    securityScore: 0,
    securityResults: [],
  });

  // Sync credits from hook
  useEffect(() => {
    if (!creditsLoading) {
      setState(prev => ({ ...prev, credits }));
    }
  }, [credits, creditsLoading]);

  const concatenatedCode = useMemo(() => buildConcatenatedCode(state.files), [state.files]);
  const saveTimerRef = useRef<number | null>(null);
  const filesRef = useRef(state.files);
  useEffect(() => { filesRef.current = state.files; }, [state.files]);

  // Load or create the user's current project
  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data } = await supabase.auth.getUser();
      const userId = data.user?.id;
      if (!userId) return;

      const { data: existing, error } = await supabase
        .from("projects")
        .select("id, name, schema, code, updated_at")
        .eq("user_id", userId)
        .order("updated_at", { ascending: false })
        .limit(1);

      if (!mounted) return;
      if (error) return;

      if (existing && existing.length > 0) {
        const proj = existing[0] as any;
        const files = deserializeFiles(proj.code);
        setState(prev => ({ ...prev, projectId: proj.id, files, activeFile: 'App.tsx' }));
        return;
      }

      const defaultSchema = { version: "3.0.0", app_name: "New Project", components: [] };
      const { data: inserted } = await supabase
        .from("projects")
        .insert({ user_id: userId, name: "New Project", schema: defaultSchema, code: serializeFiles(DEFAULT_FILES) } as any)
        .select("id")
        .single();
      if (!mounted) return;
      setState(prev => ({ ...prev, projectId: (inserted as any)?.id }));
    })();
    return () => { mounted = false; };
  }, []);

  // Autosave files to backend (debounced)
  useEffect(() => {
    if (!state.projectId || state.isDeploying) return;
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
    saveTimerRef.current = window.setTimeout(async () => {
      try {
        const { data } = await supabase.auth.getUser();
        const userId = data.user?.id;
        if (!userId) return;
        await supabase
          .from("projects")
          .update({ code: serializeFiles(filesRef.current) } as any)
          .eq("id", state.projectId)
          .eq("user_id", userId);
      } catch { /* ignore */ }
    }, 900);
    return () => { if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current); };
  }, [state.files, state.projectId, state.isDeploying]);

  const fetchSuggestions = useCallback(async () => {
    const mockSuggestions: AISuggestion[] = [
      { id: "sug_1", label: "Ajouter une page pricing", description: "Crée une section Pricing avec 3 plans et CTA.", prompt: "Ajoute une section pricing moderne avec 3 plans et un CTA.", icon: "layout" },
      { id: "sug_2", label: "Dashboard analytics", description: "Ajoute une page dashboard avec tableaux + graphiques.", prompt: "Ajoute un dashboard analytics avec 2 charts et une table.", icon: "chart" },
      { id: "sug_3", label: "Formulaire onboarding", description: "Collecte le nom, entreprise, objectifs.", prompt: "Ajoute un formulaire onboarding (nom, entreprise, objectifs).", icon: "form" },
    ];
    setState(prev => ({ ...prev, suggestions: mockSuggestions }));
  }, []);

  const handleStopGenerating = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setState(prev => ({ ...prev, isGenerating: false, aiStatusText: null }));
  }, []);

  const handleSendMessage = useCallback(async (customPrompt?: string) => {
    const input = (customPrompt ?? state.currentInput).trim();
    if (!input || state.isGenerating) return;
    if (showLanding) setShowLanding(false);

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    const now = Date.now();
    const userMessage: Message = { id: now.toString(), role: 'user', content: input, timestamp: now };
    const assistantId = (now + 1).toString();

    let hasFirstToken = false;
    const timers: number[] = [];
    const scheduleStatus = (ms: number, text: string) => {
      timers.push(window.setTimeout(() => { if (!hasFirstToken) setState(p => ({ ...p, aiStatusText: text })); }, ms));
    };

    setState(prev => ({
      ...prev,
      isGenerating: true,
      aiStatusText: "Analyse de ta demande…",
      aiEvents: [{ id: `${Date.now()}_status_start`, type: 'status', text: "Analyse de ta demande…", timestamp: Date.now() }],
      history: [...prev.history, userMessage, { id: assistantId, role: 'assistant', content: '', timestamp: Date.now() }],
      currentInput: customPrompt ? prev.currentInput : '',
    }));

    scheduleStatus(800, "Lecture du contexte…");
    scheduleStatus(1600, "Bref, je rédige…");

    const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`;

    try {
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;
      if (!token) throw new Error("Not authenticated");

      const messagesForModel = [...state.history, userMessage].map(m => ({ role: m.role, content: m.content }));

      const resp = await fetch(CHAT_URL, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ projectId: state.projectId, files: state.files, messages: messagesForModel }),
      });

      if (!resp.ok) {
        const ct = resp.headers.get('content-type') || '';
        let msg = `Request failed (${resp.status})`;
        try {
          if (ct.includes('application/json')) { const j = await resp.json(); msg = (j as any)?.error || msg; }
          else { msg = (await resp.text()) || msg; }
        } catch { /* ignore */ }
        if (resp.status === 429) throw new Error('Rate limit dépassé.');
        if (resp.status === 402) throw new Error('Crédits IA épuisés.');
        throw new Error(msg);
      }
      if (!resp.body) throw new Error('Stream not available');

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = '';
      let assistantSoFar = '';
      let streamDone = false;

      const pushEvent = (type: 'status' | 'tool' | 'error', text: string) => {
        setState(prev => ({ ...prev, aiEvents: [...(prev.aiEvents ?? []), { id: `${Date.now()}_${type}`, type, text, timestamp: Date.now() }].slice(-50) }));
      };

      const upsertAssistant = (chunk: string) => {
        assistantSoFar += chunk;
        setState(prev => ({ ...prev, history: prev.history.map(m => m.id === assistantId ? { ...m, content: assistantSoFar } : m) }));
      };

      const processParsedEvent = (parsed: any) => {
        if (parsed?.type === 'status') { setState(p => ({ ...p, aiStatusText: parsed.text ?? null })); pushEvent('status', parsed.text ?? ''); return true; }
        if (parsed?.type === 'tool') { pushEvent('tool', parsed.text ?? ''); return true; }
        if (parsed?.type === 'error') { pushEvent('error', parsed.text ?? ''); return true; }
        if (parsed?.type === 'files_update') {
          const newFiles = parsed.files as Record<string, string> | undefined;
          if (newFiles && typeof newFiles === 'object') {
            setState(p => ({ ...p, files: newFiles }));
            pushEvent('tool', `✓ ${Object.keys(newFiles).length} fichier(s) mis à jour`);
          }
          return true;
        }
        // Legacy code_update
        if (parsed?.type === 'code_update') {
          const code = parsed.code as string | undefined;
          if (code) { setState(p => ({ ...p, files: { ...p.files, 'App.tsx': code } })); pushEvent('tool', '✓ Preview mise à jour'); }
          return true;
        }
        if (parsed?.type === 'delta') {
          const content = parsed.text as string | undefined;
          if (content) {
            if (!hasFirstToken) { hasFirstToken = true; setState(p => ({ ...p, aiStatusText: "Bref, voilà :" })); }
            upsertAssistant(content);
          }
          return true;
        }
        const content = parsed?.choices?.[0]?.delta?.content as string | undefined;
        if (content) {
          if (!hasFirstToken) { hasFirstToken = true; setState(p => ({ ...p, aiStatusText: "Bref, voilà :" })); }
          upsertAssistant(content);
          return true;
        }
        return false;
      };

      const processSseLine = (line: string) => {
        if (line.endsWith('\r')) line = line.slice(0, -1);
        if (line.startsWith(':') || line.trim() === '') return { handled: true, rebuffered: false };
        if (!line.startsWith('data: ')) return { handled: false, rebuffered: false };
        const jsonStr = line.slice(6).trim();
        if (jsonStr === '[DONE]') { streamDone = true; return { handled: true, rebuffered: false }; }
        try { processParsedEvent(JSON.parse(jsonStr)); return { handled: true, rebuffered: false }; }
        catch { textBuffer = line + '\n' + textBuffer; return { handled: true, rebuffered: true }; }
      };

      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });
        let nl: number;
        while ((nl = textBuffer.indexOf('\n')) !== -1) {
          const line = textBuffer.slice(0, nl);
          textBuffer = textBuffer.slice(nl + 1);
          const res = processSseLine(line);
          if (streamDone) break;
          if (res.rebuffered) break;
        }
      }

      if (textBuffer.trim()) {
        for (const raw of textBuffer.split('\n')) {
          if (!raw) continue;
          processSseLine(raw);
          if (streamDone) break;
        }
      }

      setState(prev => ({ ...prev, isGenerating: false, aiStatusText: null }));
      abortRef.current = null;
      fetchSuggestions();
    } catch (e: any) {
      if (e?.name === 'AbortError') return;
      setState(prev => ({
        ...prev, isGenerating: false, aiStatusText: null,
        history: [...prev.history, { id: Date.now().toString(), role: 'assistant', content: "Désolé — je n'ai pas pu générer la réponse. Réessaie dans un instant.", timestamp: Date.now() }],
      }));
      abortRef.current = null;
    } finally {
      timers.forEach(t => window.clearTimeout(t));
    }
  }, [state.currentInput, state.isGenerating, state.history, state.files, fetchSuggestions, showLanding, state.projectId]);

  const handlePublish = useCallback(async () => {
    const filesSnapshot = { ...state.files };
    setState(prev => ({ ...prev, isDeploying: true, deploymentProgress: 0, deployedUrl: null }));

    // Simulate progress while building
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 10;
      if (progress < 90) {
        setState(prev => ({ ...prev, deploymentProgress: Math.min(progress, 90) }));
      }
    }, 300);

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      if (!token || !state.projectId) throw new Error('Not authenticated');

      // Call build-deploy edge function
      const resp = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/build-deploy`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          projectId: state.projectId,
          files: filesSnapshot,
          appName: 'Blink App',
        }),
      });

      clearInterval(interval);
      setState(prev => ({ ...prev, deploymentProgress: 100 }));

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: 'Deploy failed' }));
        throw new Error(err.error || 'Deploy failed');
      }

      const result = await resp.json();
      
      setTimeout(() => {
        setState(prev => ({
          ...prev,
          isDeploying: false,
          deployedUrl: result.url,
          deploymentHistory: [
            { id: result.deploymentId, url: result.url, created_at: result.createdAt },
            ...(prev.deploymentHistory ?? []),
          ].slice(0, 10),
        }));
        toast.success('🚀 Déploiement réussi!', {
          description: 'Ton app est maintenant en ligne.',
          action: {
            label: 'Ouvrir',
            onClick: () => window.open(result.url, '_blank'),
          },
        });
      }, 500);
    } catch (e: any) {
      clearInterval(interval);
      setState(prev => ({ ...prev, isDeploying: false, deployedUrl: null }));
      toast.error('Échec du déploiement', { description: e?.message });
    }
  }, [state.files, state.projectId]);

  const handleUpgrade = useCallback(() => navigate('/pricing'), [navigate]);

  const handleRunSecurity = useCallback(() => {
    setState(prev => ({ ...prev, showSecurityModal: true, isRunningSecurity: true, securityScore: 0, securityResults: [] }));
    setTimeout(() => {
      const results: SecurityResult[] = [
        { name: "SSL/TLS Encryption", status: 'passed', description: "All traffic encrypted via TLS 1.3." },
        { name: "XSS Protection", status: 'passed', description: "Automatic input sanitization active." },
        { name: "CSRF Protection", status: 'passed', description: "Anti-forgery tokens validated." },
        { name: "Rate Limiting", status: 'warning', description: "Per-endpoint tuning recommended." },
        { name: "Dependency Audit", status: 'passed', description: "All dependencies up to date." },
        { name: "Headers Security", status: 'info', description: "CSP header could be more restrictive." },
      ];
      setState(prev => ({ ...prev, isRunningSecurity: false, securityScore: 94, securityResults: results }));
    }, 2500);
  }, []);

  const handleNewProject = useCallback(() => {
    if (confirm("Créer un nouveau projet ? Les changements actuels seront perdus.")) {
      setState(prev => ({
        ...prev,
        files: { ...DEFAULT_FILES },
        activeFile: 'App.tsx',
        history: [{ id: Date.now().toString(), role: 'assistant', content: "Projet réinitialisé. Comment puis-je vous aider ?", timestamp: Date.now() }],
        selectedWidgetId: undefined,
      }));
    }
  }, []);

  const handleStartFromLanding = (prompt: string) => {
    setState(prev => ({ ...prev, currentInput: prompt }));
    handleSendMessage(prompt);
  };

  // Toggle Visual Edit Mode
  const handleToggleVisualEdit = useCallback(() => {
    setState(prev => ({ ...prev, isVisualEditMode: !prev.isVisualEditMode }));
  }, []);

  // Screenshot capture handler
  const handleScreenshotRequest = useCallback(() => {
    // For now, show a toast that screenshot is being captured
    // In a real implementation, this would capture the preview iframe content
    toast.info('📸 Capturing screenshot...', { description: 'Screenshot will be attached to your next message.' });
    
    // Simulate screenshot capture delay
    setTimeout(() => {
      // Create a placeholder data URL (in production, this would be actual canvas capture)
      const placeholderDataUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
      setState(prev => ({ ...prev, screenshotAttachment: placeholderDataUrl }));
      toast.success('✅ Screenshot captured!', { description: 'Ready to send with your next message.' });
    }, 500);
  }, []);

  // Show history modal
  const handleShowHistory = useCallback(() => {
    setState(prev => ({ ...prev, showHistoryModal: true }));
  }, []);

  return (
    <div className="dark">
      <div className="flex h-screen bg-background overflow-hidden select-none relative">
        <Sidebar 
          state={state} 
          setState={setState} 
          onSend={handleSendMessage} 
          onStop={handleStopGenerating}
          onScreenshotRequest={handleScreenshotRequest}
          onToggleVisualEdit={handleToggleVisualEdit}
          onShowHistory={handleShowHistory}
        />
        <div className="flex-1 flex flex-col min-w-0">
          <TopNav
            onBackToLanding={() => setShowLanding(true)}
            onPublish={handlePublish}
            onUpgrade={handleUpgrade}
            onRunSecurity={handleRunSecurity}
            onNewProject={handleNewProject}
            onToggleCodeView={() => setState(prev => ({ ...prev, isCodeView: !prev.isCodeView }))}
            isCodeView={state.isCodeView}
            isGenerating={state.isGenerating}
          />
          <CodePreview code={concatenatedCode} isGenerating={state.isGenerating} />
          
          {/* Console Panel */}
          <ConsolePanel
            logs={consoleLogs}
            onClear={clearConsoleLogs}
            isOpen={consoleOpen}
            onToggle={() => setConsoleOpen(!consoleOpen)}
          />
        </div>

        {/* Upgrade Modal */}
        {state.showUpgradeModal && (
          <div className="fixed inset-0 z-[1000] bg-background/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
            <div className="bg-card border border-border w-full max-w-2xl rounded-[40px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
              <div className="relative p-12">
                <button onClick={() => setState(prev => ({ ...prev, showUpgradeModal: false }))} className="absolute top-8 right-8 text-muted-foreground hover:text-foreground transition-colors"><X size={24} /></button>
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center mb-8"><Zap size={40} className="text-primary-foreground" /></div>
                  <h2 className="text-4xl font-black text-foreground mb-4 tracking-tight">Upgrade to Blink Pro</h2>
                  <p className="text-muted-foreground font-medium text-lg max-w-md mb-12">Libérez toute la puissance de l'IA avec des builds illimités.</p>
                  <div className="grid grid-cols-2 gap-6 w-full mb-12">
                    <div className="bg-muted p-6 rounded-3xl border border-border text-left">
                      <div className="flex items-center gap-2 text-primary mb-2 font-black text-xs uppercase tracking-widest"><CheckCircle2 size={14} /> Performance</div>
                      <p className="text-foreground font-bold">Modèles Ultra-rapides</p>
                      <p className="text-muted-foreground text-sm mt-1">Accès prioritaire aux GPU H100.</p>
                    </div>
                    <div className="bg-muted p-6 rounded-3xl border border-border text-left">
                      <div className="flex items-center gap-2 text-primary mb-2 font-black text-xs uppercase tracking-widest"><CheckCircle2 size={14} /> Privacy</div>
                      <p className="text-foreground font-bold">Mode Privé</p>
                      <p className="text-muted-foreground text-sm mt-1">Vos données ne sont pas entraînées.</p>
                    </div>
                  </div>
                  <button onClick={() => setState(prev => ({ ...prev, credits: prev.credits + 50, showUpgradeModal: false }))} className="w-full py-5 bg-primary text-primary-foreground rounded-2xl font-black text-lg hover:opacity-90 transition-all active:scale-95 flex items-center justify-center gap-2">
                    Passer Pro - $29/mois <Rocket size={20} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Security Modal */}
        {state.showSecurityModal && (
          <div className="fixed inset-0 z-[1000] bg-background/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
            <div className="bg-card border border-border w-full max-w-xl rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
              <div className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-xl text-primary"><ShieldCheck size={24} /></div>
                    <div>
                      <h3 className="text-xl font-black text-foreground">Security Run</h3>
                      <p className="text-xs text-muted-foreground font-bold uppercase tracking-widest">Infrastructure Scan</p>
                    </div>
                  </div>
                  <button onClick={() => setState(prev => ({ ...prev, showSecurityModal: false }))} className="p-2 text-muted-foreground hover:text-foreground"><X size={20} /></button>
                </div>
                {state.isRunningSecurity ? (
                  <div className="py-20 flex flex-col items-center text-center">
                    <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
                    <h4 className="text-foreground font-bold text-lg">Scanning…</h4>
                  </div>
                ) : (
                  <div className="space-y-6 animate-in fade-in duration-500">
                    <div className="flex items-center justify-between p-6 bg-muted rounded-2xl border border-border">
                      <div>
                        <div className="text-3xl font-black text-foreground">{state.securityScore}%</div>
                        <div className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mt-1">Security Score</div>
                      </div>
                      <div className="px-4 py-1.5 rounded-full text-[10px] font-black uppercase bg-primary/20 text-primary">High</div>
                    </div>
                    <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                      {state.securityResults?.map((res, i) => (
                        <div key={i} className="flex items-start gap-4 p-4 bg-muted rounded-xl border border-border">
                          <div className="mt-0.5 text-primary">
                            {res.status === 'passed' ? <CheckCircle2 size={16} /> : res.status === 'warning' ? <AlertTriangle size={16} /> : <Info size={16} />}
                          </div>
                          <div>
                            <div className="text-xs font-black text-foreground">{res.name}</div>
                            <div className="text-[11px] text-muted-foreground mt-1">{res.description}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => setState(prev => ({ ...prev, showSecurityModal: false }))} className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-black text-sm hover:opacity-90">Close Report</button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* History Modal */}
        {state.showHistoryModal && (
          <div className="fixed inset-0 z-[1000] bg-background/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
            <div className="bg-card border border-border w-full max-w-xl rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
              <div className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-amber-500/10 rounded-xl text-amber-500"><History size={24} /></div>
                    <div>
                      <h3 className="text-xl font-black text-foreground">Conversation History</h3>
                      <p className="text-xs text-muted-foreground font-bold uppercase tracking-widest">All your messages</p>
                    </div>
                  </div>
                  <button onClick={() => setState(prev => ({ ...prev, showHistoryModal: false }))} className="p-2 text-muted-foreground hover:text-foreground"><X size={20} /></button>
                </div>
                
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {state.history.length === 0 ? (
                    <div className="py-12 text-center text-muted-foreground">
                      <History size={48} className="mx-auto mb-4 opacity-30" />
                      <p>No messages yet</p>
                    </div>
                  ) : (
                    state.history.map((msg, i) => (
                      <div key={msg.id} className="flex items-start gap-3 p-4 bg-muted rounded-xl border border-border">
                        <div className={`shrink-0 w-8 h-8 rounded-lg flex items-center justify-center ${msg.role === 'assistant' ? 'bg-primary/10 text-primary' : 'bg-muted-foreground/10 text-muted-foreground'}`}>
                          {msg.role === 'assistant' ? '🤖' : '👤'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-black text-muted-foreground uppercase">{msg.role === 'assistant' ? 'BLINK' : 'YOU'}</span>
                            <span className="text-[9px] text-muted-foreground/60 font-mono">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                          </div>
                          <p className="text-sm text-foreground line-clamp-3">{msg.content}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <div className="mt-6 flex gap-3">
                  <button 
                    onClick={() => {
                      if (confirm('Clear all conversation history?')) {
                        setState(prev => ({ 
                          ...prev, 
                          history: [{ id: Date.now().toString(), role: 'assistant', content: "History cleared. How can I help you?", timestamp: Date.now() }],
                          showHistoryModal: false 
                        }));
                      }
                    }} 
                    className="flex-1 py-3 bg-destructive/10 text-destructive rounded-xl font-bold text-sm hover:bg-destructive/20 transition-all"
                  >
                    Clear History
                  </button>
                  <button onClick={() => setState(prev => ({ ...prev, showHistoryModal: false }))} className="flex-1 py-3 bg-primary text-primary-foreground rounded-xl font-bold text-sm hover:opacity-90 transition-all">
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;
