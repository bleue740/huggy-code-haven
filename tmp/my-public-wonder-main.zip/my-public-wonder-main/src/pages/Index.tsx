// Home page now renders the imported GitHub app (AI disabled).

import AppBuilder from "@/app-builder/App";

const Index = () => {
  return <AppBuilder />;
};

export default Index;
