import React, { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { PreviewArea } from "@/app-builder/components/PreviewArea";

type DeploymentRow = {
  id: string;
  slug: string;
  schema_snapshot: any;
};

export default function PublishedDeploymentPage() {
  const { deploymentId } = useParams();
  const [row, setRow] = useState<DeploymentRow | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      setIsLoading(true);
      setError(null);
      try {
        if (!deploymentId) throw new Error("Missing deployment id");
        const { data, error } = await supabase
          .from("deployments")
          .select("id, slug, schema_snapshot")
          .eq("id", deploymentId)
          .maybeSingle();
        if (error) throw error;
        if (!data) throw new Error("Not found");
        if (mounted) setRow(data as any);
      } catch (e: any) {
        if (mounted) setError(e?.message ?? "Not found");
      } finally {
        if (mounted) setIsLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [deploymentId]);

  const codeContent = useMemo(() => {
    if (!row) return "";
    const appName = row.slug?.replace(/-/g, " ") ?? "Published";
    return JSON.stringify(
      { version: "2.0.0", app_name: appName, components: row.schema_snapshot?.components ?? row.schema_snapshot?.components ?? [] },
      null,
      2
    );
  }, [row]);

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-sm text-muted-foreground">Loading…</div>
      </main>
    );
  }

  if (error || !row) {
    return (
      <main className="min-h-screen bg-background text-foreground flex items-center justify-center p-6">
        <div className="text-center">
          <h1 className="text-2xl font-black">Deployment introuvable</h1>
          <p className="text-sm text-muted-foreground mt-2">{error}</p>
        </div>
      </main>
    );
  }

  // Read-only preview; disable selection/edit callbacks.
  return (
    <div className="dark h-screen">
      <div className="flex h-screen bg-background overflow-hidden select-none relative">
        <PreviewArea
          isGenerating={false}
          codeContent={codeContent}
          selectedWidgetId={undefined}
          onSelectWidget={() => {}}
        />
      </div>
    </div>
  );
}
