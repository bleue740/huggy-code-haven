
# Plan : Capture d'écran, Visual Edit mode, Menu "+" amélioré et corrections

## Analyse des problèmes actuels

Après examen du code, voici les incohérences identifiées :

### Problème 1 : Bouton Chat bleu même en mode Chat
**Ligne 533** : `${!isCodeView ? 'bg-blue-600 text-white' : ...}`
- Le bouton Chat est bleu quand `!isCodeView` (donc en mode Chat)
- Il devrait être bleu uniquement quand on N'EST PAS en mode Chat (logique inversée)

### Problème 2 : Screenshot ne fait rien
**Ligne 220-224** : `handleScreenshot` est un placeholder qui log seulement

### Problème 3 : Visual Edit Mode non connecté
**Ligne 61** : `isVisualEditMode` est un état local dans Sidebar, non propagé à PreviewArea

### Problème 4 : Menu "+" design basique
- Manque l'option "History"
- Design plat sans séparateurs ni icônes améliorées

### Problème 5 : Bouton Chat logique incohérente
- En mode Chat, le bouton Chat est bleu alors qu'on devrait montrer qu'on EST en mode Chat
- Le comportement attendu : bleu = "cliquez pour aller vers Chat" quand on est en Code view

---

## Corrections à implémenter

### 1. Fichier : `src/app-builder/types.ts`
Ajouter `isVisualEditMode` à AppState pour le partager entre Sidebar et PreviewArea.

### 2. Fichier : `src/app-builder/components/Sidebar.tsx`

**A. Corriger le bouton Chat (ligne 533)**
```tsx
// AVANT (incorrect)
className={`... ${!isCodeView ? 'bg-blue-600 text-white' : 'bg-[#262626] text-neutral-300 hover:bg-[#333]'}`}

// APRÈS (correct) - bleu quand on EST en mode Code (pour indiquer "cliquez pour aller en Chat")
className={`... ${isCodeView ? 'bg-blue-600 text-white' : 'bg-[#262626] text-neutral-300 hover:bg-[#333]'}`}
```

**B. Ajouter props pour Visual Edit et Screenshot**
```tsx
interface SidebarProps {
  // ... existing
  onScreenshotRequest?: () => void;
  isVisualEditMode?: boolean;
  onToggleVisualEdit?: () => void;
}
```

**C. Améliorer le menu "+" avec History et meilleur design**
- Ajouter séparateurs visuels
- Ajouter option "History" avec icône
- Améliorer les icônes et couleurs

**D. Implémenter handleScreenshot**
```tsx
const handleScreenshot = () => {
  setShowAttachMenu(false);
  if (onScreenshotRequest) {
    onScreenshotRequest();
  }
};
```

### 3. Fichier : `src/app-builder/components/PreviewArea.tsx`

**A. Ajouter prop `isVisualEditMode` et `onScreenshotCapture`**
```tsx
interface PreviewAreaProps {
  // ... existing
  isVisualEditMode?: boolean;
  onScreenshotCapture?: (dataUrl: string) => void;
}
```

**B. Implémenter la capture d'écran avec html2canvas**
Utiliser l'API native `canvas` ou créer un rendu du contenu :
```tsx
const captureScreenshot = async () => {
  const previewElement = document.querySelector('[data-preview-frame]');
  if (previewElement) {
    // Utiliser html2canvas ou une approche canvas
    // Retourner le dataUrl
  }
};
```

**C. Indicateur visuel pour Visual Edit Mode**
Quand `isVisualEditMode` est actif, afficher une bordure/overlay spécial et permettre la sélection d'éléments avec highlight.

### 4. Fichier : `src/app-builder/App.tsx`

**A. Lever l'état `isVisualEditMode` au niveau App**
```tsx
const [isVisualEditMode, setIsVisualEditMode] = useState(false);
```

**B. Ajouter handler pour screenshot**
```tsx
const handleScreenshotCapture = useCallback((dataUrl: string) => {
  // Ajouter au contexte du message ou afficher preview
  toast.success('Screenshot captured!');
  // Optionnel: ajouter comme attachment au prochain message
}, []);
```

**C. Passer les props aux composants**

---

## Design amélioré du Menu "+"

```text
┌─────────────────────────────────┐
│  📎 Attach Image                │
│  📄 Attach File                 │
│  ─────────────────────────────  │
│  📸 Screenshot                  │  ← Capture la preview
│  🔗 Import URL                  │
│  ─────────────────────────────  │
│  🕐 History                     │  ← Nouveau : voir l'historique
└─────────────────────────────────┘
```

---

## Fonctionnement du Visual Edit Mode

Quand activé :
1. PreviewArea affiche un overlay "Visual Edit Mode" avec instructions
2. Cliquer sur un élément dans la preview le sélectionne
3. Un panneau de propriétés apparaît (déjà existant)
4. Le curseur change en `crosshair`

---

## Résumé des fichiers à modifier

| Fichier | Modifications |
|---------|---------------|
| `src/app-builder/types.ts` | Ajouter `isVisualEditMode` à AppState |
| `src/app-builder/components/Sidebar.tsx` | Corriger bouton Chat, améliorer menu "+", ajouter History, connecter screenshot/visual |
| `src/app-builder/components/PreviewArea.tsx` | Ajouter capture screenshot, overlay visual edit mode |
| `src/app-builder/App.tsx` | Lever état isVisualEditMode, ajouter handlers screenshot/history |

---

## Détails techniques

### Screenshot avec Canvas API
```tsx
const capturePreviewScreenshot = async (): Promise<string | null> => {
  const iframe = document.querySelector('iframe[data-preview]') as HTMLIFrameElement;
  if (!iframe) return null;
  
  // Pour un iframe same-origin, on peut utiliser html2canvas
  // Alternative: utiliser une approche de rendu côté serveur
  
  try {
    // Approche simplifiée: screenshot de l'élément preview entier
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    // ... render logic
    return canvas.toDataURL('image/png');
  } catch {
    return null;
  }
};
```

### Visual Edit Mode Overlay
```tsx
{isVisualEditMode && (
  <div className="absolute inset-0 z-[50] pointer-events-none">
    <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg animate-pulse">
      Visual Edit Mode — Click any element to edit
    </div>
    {/* Overlay pour indiquer les zones cliquables */}
  </div>
)}
```

### Bouton History dans le menu
```tsx
<div className="h-[1px] bg-[#333] my-1" /> {/* Séparateur */}
<button 
  onClick={handleShowHistory}
  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-neutral-300 hover:bg-white/5 rounded-lg"
>
  <HistoryIcon size={14} className="text-amber-400" /> History
</button>
```

---

## Avantages des corrections

1. **Cohérence UX** : Bouton Chat bleu seulement quand pertinent
2. **Screenshot fonctionnel** : Capture réelle de la preview
3. **Visual Edit connecté** : Mode intégré entre Sidebar et Preview
4. **Menu "+" enrichi** : History + meilleur design
5. **Code maintenable** : États levés au niveau App pour partage
